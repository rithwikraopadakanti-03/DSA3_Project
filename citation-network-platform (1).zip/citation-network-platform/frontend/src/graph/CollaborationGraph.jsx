import { useEffect, useRef } from 'react'
import cytoscape from 'cytoscape'

/** Author collaboration graph: author = node, co-authorship = undirected edge. */
export default function CollaborationGraph({ nodes, edges, onNodeClick }) {
  const containerRef = useRef(null)

  useEffect(() => {
    if (!containerRef.current) return

    const elements = [
      ...nodes.map((n) => ({
        data: { id: String(n.id), label: n.label, size: 18 + Math.min(28, (n.publications || 0) * 3) },
      })),
      ...edges.map((e, idx) => ({
        data: { id: `ce${idx}`, source: String(e.source), target: String(e.target), weight: e.weight },
      })),
    ]

    const cy = cytoscape({
      container: containerRef.current,
      elements,
      style: [
        {
          selector: 'node',
          style: {
            'background-color': '#2563eb',
            label: 'data(label)',
            'font-size': 9,
            color: '#0f172a',
            'text-valign': 'bottom',
            'text-margin-y': 4,
            width: 'data(size)',
            height: 'data(size)',
            'border-width': 1,
            'border-color': '#ffffff',
          },
        },
        {
          selector: 'edge',
          style: {
            width: (ele) => 1 + Math.min(4, ele.data('weight')),
            'line-color': '#fca5a5',
            'curve-style': 'bezier',
          },
        },
      ],
      layout: { name: 'cose', animate: false, padding: 30 },
      wheelSensitivity: 0.2,
    })

    if (onNodeClick) cy.on('tap', 'node', (evt) => onNodeClick(evt.target.id()))

    return () => cy.destroy()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [nodes, edges])

  return <div ref={containerRef} className="w-full h-full" />
}
