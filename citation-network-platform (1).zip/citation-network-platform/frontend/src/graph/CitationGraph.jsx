import { useEffect, useRef } from 'react'
import cytoscape from 'cytoscape'

const COMMUNITY_COLORS = ['#2563eb', '#dc2626', '#059669', '#d97706', '#7c3aed', '#0891b2', '#be185d']

/**
 * Renders the citation network with Cytoscape.js.
 * Props:
 *  - nodes: [{id, label, year, citation_count, pagerank, community, authors}]
 *  - edges: [{source, target}]
 *  - onNodeClick(nodeId)
 *  - highlightPath: [ids] (optional) — highlights a path (e.g. from BFS/DFS/path finder)
 *  - highlightSet: Set of ids (optional) — highlights arbitrary set of visited nodes
 */
export default function CitationGraph({ nodes, edges, onNodeClick, highlightPath, highlightSet }) {
  const containerRef = useRef(null)
  const cyRef = useRef(null)

  useEffect(() => {
    if (!containerRef.current) return

    const elements = [
      ...nodes.map((n) => ({
        data: {
          id: String(n.id),
          label: n.label.length > 28 ? n.label.slice(0, 26) + '…' : n.label,
          community: n.community ?? 0,
          size: 20 + Math.min(30, (n.citation_count || 0) * 2),
        },
      })),
      ...edges.map((e) => ({
        data: { id: `e${e.source}-${e.target}`, source: String(e.source), target: String(e.target) },
      })),
    ]

    const cy = cytoscape({
      container: containerRef.current,
      elements,
      style: [
        {
          selector: 'node',
          style: {
            'background-color': (ele) => COMMUNITY_COLORS[ele.data('community') % COMMUNITY_COLORS.length],
            label: 'data(label)',
            'font-size': 8,
            color: '#0f172a',
            'text-valign': 'bottom',
            'text-margin-y': 4,
            width: 'data(size)',
            height: 'data(size)',
            'border-width': 1,
            'border-color': '#ffffff',
          },
        },
        {
          selector: 'edge',
          style: {
            width: 1,
            'line-color': '#cbd5e1',
            'target-arrow-color': '#cbd5e1',
            'target-arrow-shape': 'triangle',
            'curve-style': 'bezier',
            'arrow-scale': 0.7,
          },
        },
        {
          selector: '.highlighted-node',
          style: { 'border-width': 3, 'border-color': '#0f172a', 'background-color': '#dc2626' },
        },
        {
          selector: '.highlighted-edge',
          style: { 'line-color': '#dc2626', 'target-arrow-color': '#dc2626', width: 3 },
        },
        {
          selector: '.dimmed',
          style: { opacity: 0.15 },
        },
      ],
      layout: { name: 'cose', animate: false, padding: 30 },
      wheelSensitivity: 0.2,
    })

    if (onNodeClick) {
      cy.on('tap', 'node', (evt) => onNodeClick(evt.target.id()))
    }

    cyRef.current = cy
    return () => cy.destroy()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [nodes, edges])

  useEffect(() => {
    const cy = cyRef.current
    if (!cy) return
    cy.elements().removeClass('highlighted-node highlighted-edge dimmed')

    if (highlightPath && highlightPath.length > 0) {
      const idSet = new Set(highlightPath.map(String))
      cy.nodes().forEach((n) => {
        if (idSet.has(n.id())) n.addClass('highlighted-node')
        else n.addClass('dimmed')
      })
      for (let i = 0; i < highlightPath.length - 1; i++) {
        const edge = cy.edges(`[source = "${highlightPath[i]}"][target = "${highlightPath[i + 1]}"]`)
        edge.addClass('highlighted-edge')
      }
    } else if (highlightSet && highlightSet.size > 0) {
      cy.nodes().forEach((n) => {
        if (highlightSet.has(Number(n.id())) || highlightSet.has(n.id())) n.addClass('highlighted-node')
        else n.addClass('dimmed')
      })
    }
  }, [highlightPath, highlightSet])

  return <div ref={containerRef} className="w-full h-full" />
}
