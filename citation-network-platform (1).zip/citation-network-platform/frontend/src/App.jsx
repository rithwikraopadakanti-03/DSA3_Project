import { Routes, Route } from 'react-router-dom'
import Dashboard from './pages/Dashboard.jsx'
import CitationNetwork from './pages/CitationNetwork.jsx'
import PaperExplorer from './pages/PaperExplorer.jsx'
import PaperDetails from './pages/PaperDetails.jsx'
import CitationPathFinder from './pages/CitationPathFinder.jsx'
import BFSAnalysis from './pages/BFSAnalysis.jsx'
import DFSAnalysis from './pages/DFSAnalysis.jsx'
import AlgorithmComparison from './pages/AlgorithmComparison.jsx'
import PageRank from './pages/PageRank.jsx'
import Communities from './pages/Communities.jsx'
import Authors from './pages/Authors.jsx'
import Collaborations from './pages/Collaborations.jsx'
import DataManagement from './pages/DataManagement.jsx'
import About from './pages/About.jsx'

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Dashboard />} />
      <Route path="/network" element={<CitationNetwork />} />
      <Route path="/papers" element={<PaperExplorer />} />
      <Route path="/papers/:id" element={<PaperDetails />} />
      <Route path="/citation-paths" element={<CitationPathFinder />} />
      <Route path="/bfs" element={<BFSAnalysis />} />
      <Route path="/dfs" element={<DFSAnalysis />} />
      <Route path="/algorithm-comparison" element={<AlgorithmComparison />} />
      <Route path="/pagerank" element={<PageRank />} />
      <Route path="/communities" element={<Communities />} />
      <Route path="/authors" element={<Authors />} />
      <Route path="/collaborations" element={<Collaborations />} />
      <Route path="/data-management" element={<DataManagement />} />
      <Route path="/about" element={<About />} />
    </Routes>
  )
}
