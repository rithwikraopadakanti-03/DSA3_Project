import axios from 'axios'

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000'

const client = axios.create({ baseURL: API_BASE_URL })

export const api = {
  getStatistics: () => client.get('/api/statistics').then((r) => r.data),
  getPapers: (params) => client.get('/api/papers', { params }).then((r) => r.data),
  getPaper: (id) => client.get(`/api/papers/${id}`).then((r) => r.data),
  getAuthors: (params) => client.get('/api/authors', { params }).then((r) => r.data),
  getAuthor: (id) => client.get(`/api/authors/${id}`).then((r) => r.data),
  getNetwork: () => client.get('/api/network').then((r) => r.data),
  getCollaborationNetwork: () => client.get('/api/network/collaborations').then((r) => r.data),
  getCollaborationSummary: () => client.get('/api/collaborations').then((r) => r.data),
  getCommunities: () => client.get('/api/communities').then((r) => r.data),
  getCommunity: (id) => client.get(`/api/communities/${id}`).then((r) => r.data),
  getPageRank: () => client.get('/api/pagerank').then((r) => r.data),
  runBFS: (start_paper_id) => client.post('/api/bfs', { start_paper_id }).then((r) => r.data),
  runDFS: (start_paper_id) => client.post('/api/dfs', { start_paper_id }).then((r) => r.data),
  findCitationPath: (start_paper_id, target_paper_id, algorithm) =>
    client.post('/api/citation-path', { start_paper_id, target_paper_id, algorithm }).then((r) => r.data),
  validateDataset: (file) => {
    const form = new FormData()
    form.append('file', file)
    return client.post('/api/import/validate', form).then((r) => r.data)
  },
  importDataset: (file) => {
    const form = new FormData()
    form.append('file', file)
    return client.post('/api/import', form).then((r) => r.data)
  },
  deleteDataset: () => client.delete('/api/import').then((r) => r.data),
  getDatasetStats: () => client.get('/api/import/stats').then((r) => r.data),
  health: () => client.get('/api/health').then((r) => r.data),
}

export default api
