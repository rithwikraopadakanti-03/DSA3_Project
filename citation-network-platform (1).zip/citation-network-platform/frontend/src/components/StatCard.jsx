export default function StatCard({ label, value, accent = 'blue' }) {
  const accentClass = accent === 'red' ? 'text-accent-red' : 'text-accent-blue'
  return (
    <div className="card">
      <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">{label}</p>
      <p className={`text-3xl font-bold mt-2 ${accentClass}`}>{value}</p>
    </div>
  )
}
