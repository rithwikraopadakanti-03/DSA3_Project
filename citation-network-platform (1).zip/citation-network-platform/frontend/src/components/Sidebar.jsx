import { NavLink } from 'react-router-dom'

const SECTIONS = [
  {
    heading: 'Citation Analytics',
    links: [
      { to: '/', label: 'Dashboard' },
      { to: '/network', label: 'Citation Network' },
      { to: '/papers', label: 'Paper Explorer' },
      { to: '/citation-paths', label: 'Citation Paths' },
    ],
  },
  {
    heading: 'Analysis',
    links: [
      { to: '/bfs', label: 'BFS' },
      { to: '/dfs', label: 'DFS' },
      { to: '/algorithm-comparison', label: 'Algorithm Comparison' },
      { to: '/pagerank', label: 'PageRank' },
      { to: '/communities', label: 'Communities' },
      { to: '/authors', label: 'Authors' },
      { to: '/collaborations', label: 'Collaborations' },
    ],
  },
  {
    heading: 'Data',
    links: [{ to: '/data-management', label: 'Data Management' }],
  },
  {
    heading: 'Project',
    links: [{ to: '/about', label: 'About' }],
  },
]

export default function Sidebar() {
  return (
    <aside className="w-64 shrink-0 bg-navy-900 text-slate-200 min-h-screen flex flex-col">
      <div className="px-5 py-6 border-b border-navy-800">
        <h1 className="text-lg font-bold text-white leading-tight">Citation-Network</h1>
        <p className="text-xs text-slate-400 mt-0.5">Analytics Platform</p>
      </div>
      <nav className="flex-1 overflow-y-auto py-4">
        {SECTIONS.map((section) => (
          <div key={section.heading} className="mb-5 px-3">
            <p className="px-2 text-[11px] uppercase tracking-wider text-slate-500 font-semibold mb-1.5">
              {section.heading}
            </p>
            {section.links.map((link) => (
              <NavLink
                key={link.to}
                to={link.to}
                end={link.to === '/'}
                className={({ isActive }) =>
                  `block px-3 py-2 rounded-lg text-sm mb-0.5 transition-colors ${
                    isActive
                      ? 'bg-accent-blue text-white font-medium'
                      : 'text-slate-300 hover:bg-navy-800 hover:text-white'
                  }`
                }
              >
                {link.label}
              </NavLink>
            ))}
          </div>
        ))}
      </nav>
      <div className="px-5 py-4 border-t border-navy-800 text-[11px] text-slate-500">
        DSA-3 Project · Team 16
      </div>
    </aside>
  )
}
