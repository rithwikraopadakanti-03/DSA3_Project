export default function AlgorithmDetailsPanel({ name, purpose, input, output, dataStructure, timeComplexity, spaceComplexity }) {
  const rows = [
    ['Purpose', purpose],
    ['Input', input],
    ['Output', output],
    ['Data Structure Used', dataStructure],
    ['Time Complexity', timeComplexity],
    ['Space Complexity', spaceComplexity],
  ]
  return (
    <div className="card bg-navy-900 text-slate-200 border-navy-800">
      <p className="text-xs uppercase tracking-wide text-slate-400 font-semibold mb-3">
        Algorithm Details — {name}
      </p>
      <dl className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-2 text-sm">
        {rows.map(([label, value]) => (
          <div key={label} className="flex justify-between sm:block">
            <dt className="text-slate-400">{label}</dt>
            <dd className="font-medium text-white sm:mt-0.5">{value}</dd>
          </div>
        ))}
      </dl>
    </div>
  )
}
