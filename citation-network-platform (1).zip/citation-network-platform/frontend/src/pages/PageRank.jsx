import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts'
import Layout from '../components/Layout.jsx'
import AlgorithmDetailsPanel from '../components/AlgorithmDetailsPanel.jsx'
import api from '../services/api.js'

export default function PageRank() {
  const [data, setData] = useState(null)
  const [showAll, setShowAll] = useState(false)
  const [loading, setLoading] = useState(true)

  const load = () => {
    setLoading(true)
    api.getPageRank().then((d) => { setData(d); setLoading(false) })
  }

  useEffect(load, [])

  const visibleRows = data ? data.ranked_papers.slice(0, showAll ? 20 : 10) : []
  const chartData = data ? data.ranked_papers.slice(0, 10).map((p) => ({ title: p.title.slice(0, 18) + '…', score: p.pagerank_score })) : []

  return (
    <Layout>
      <h1 className="page-title">PageRank — Influential Papers</h1>
      <p className="page-subtitle">
        PageRank evaluates importance based on the structure of the citation network rather than simply counting citations.
      </p>
      <button className="btn-secondary mt-3" onClick={load} disabled={loading}>{loading ? 'Calculating…' : 'Recalculate PageRank'}</button>

      {data && (
        <>
          <div className="card mt-6">
            <h2 className="font-semibold text-navy-900 mb-3">PageRank Distribution (Top 10)</h2>
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={chartData} layout="vertical" margin={{ left: 40 }}>
                <XAxis type="number" tick={{ fontSize: 11 }} />
                <YAxis type="category" dataKey="title" width={150} tick={{ fontSize: 11 }} />
                <Tooltip />
                <Bar dataKey="score" fill="#2563eb" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="card mt-6 overflow-x-auto">
            <div className="flex justify-between items-center mb-3">
              <h2 className="font-semibold text-navy-900">Ranking Table</h2>
              <button className="text-sm text-accent-blue hover:underline" onClick={() => setShowAll(!showAll)}>
                {showAll ? 'Show Top 10' : 'Show Top 20'}
              </button>
            </div>
            <table className="table-base">
              <thead><tr><th>Rank</th><th>Paper</th><th>Citation Count</th><th>PageRank Score</th></tr></thead>
              <tbody>
                {visibleRows.map((p, idx) => (
                  <tr key={p.id}>
                    <td className="font-bold text-accent-blue">{idx + 1}</td>
                    <td><Link to={`/papers/${p.id}`} className="hover:text-accent-blue">{p.title}</Link></td>
                    <td>{p.citation_count}</td>
                    <td className="font-mono">{p.pagerank_score.toFixed(4)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="mt-6">
            <AlgorithmDetailsPanel
              name="PageRank"
              purpose="Identify influential papers based on citation network structure"
              input="Citation graph (directed)"
              output="A relative importance score per paper (sums to 1)"
              dataStructure="Sparse adjacency matrix"
              timeComplexity="O(k · (V + E)) for k iterations"
              spaceComplexity="O(V)"
            />
          </div>
        </>
      )}
    </Layout>
  )
}
