import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import Layout from '../components/Layout.jsx'
import CitationGraph from '../graph/CitationGraph.jsx'
import AlgorithmDetailsPanel from '../components/AlgorithmDetailsPanel.jsx'
import api from '../services/api.js'

export default function Communities() {
  const [data, setData] = useState(null)
  const [network, setNetwork] = useState(null)
  const [loading, setLoading] = useState(true)

  const load = () => {
    setLoading(true)
    Promise.all([api.getCommunities(), api.getNetwork()]).then(([c, n]) => {
      setData(c)
      setNetwork(n)
      setLoading(false)
    })
  }

  useEffect(load, [])

  return (
    <Layout>
      <h1 className="page-title">Research Communities</h1>
      <p className="page-subtitle">Groups of closely-connected papers, detected via greedy modularity maximization.</p>
      <button className="btn-secondary mt-3" onClick={load} disabled={loading}>{loading ? 'Detecting…' : 'Re-run Detection'}</button>

      {data && network && (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
            <div className="card"><p className="text-xs text-slate-500">Communities Found</p><p className="text-2xl font-bold text-accent-blue">{data.num_communities}</p></div>
            <div className="card"><p className="text-xs text-slate-500">Modularity Score</p><p className="text-2xl font-bold text-accent-blue">{data.modularity}</p></div>
            <div className="card"><p className="text-xs text-slate-500">Execution Time</p><p className="text-2xl font-bold text-accent-blue">{data.execution_time_ms} ms</p></div>
          </div>

          <div className="card mt-6 h-[500px] p-2">
            <CitationGraph nodes={network.nodes} edges={network.edges} />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
            {data.communities.map((c) => (
              <div key={c.community_id} className="card">
                <h2 className="font-semibold text-navy-900 mb-1">Community {c.community_id}</h2>
                <p className="text-sm text-slate-500 mb-3">{c.size} papers · avg {c.avg_citations} citations</p>
                <p className="text-sm mb-2"><strong>Top paper:</strong> {c.top_paper ? <Link to={`/papers/${c.top_paper.id}`} className="text-accent-blue hover:underline">{c.top_paper.title}</Link> : '—'}</p>
                <p className="text-sm"><strong>Main authors:</strong> {c.authors.slice(0, 5).join(', ')}</p>
              </div>
            ))}
          </div>

          <div className="mt-6">
            <AlgorithmDetailsPanel
              name="Greedy Modularity Community Detection"
              purpose="Group papers that cite each other more densely than expected by chance"
              input="Undirected citation graph"
              output="A set of communities (paper groups) and a modularity score"
              dataStructure="Priority queue over candidate merges"
              timeComplexity="≈ O(E · V) worst case on sparse graphs"
              spaceComplexity="O(V + E)"
            />
          </div>
        </>
      )}
    </Layout>
  )
}
