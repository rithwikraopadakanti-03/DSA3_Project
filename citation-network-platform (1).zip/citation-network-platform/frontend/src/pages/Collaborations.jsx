import { useEffect, useState } from 'react'
import Layout from '../components/Layout.jsx'
import CollaborationGraph from '../graph/CollaborationGraph.jsx'
import api from '../services/api.js'

export default function Collaborations() {
  const [network, setNetwork] = useState(null)
  const [summary, setSummary] = useState(null)
  const [search, setSearch] = useState('')

  useEffect(() => {
    api.getCollaborationNetwork().then(setNetwork)
    api.getCollaborationSummary().then(setSummary)
  }, [])

  const filteredNodes = network
    ? network.nodes.filter((n) => !search || n.label.toLowerCase().includes(search.toLowerCase()))
    : []
  const filteredIds = new Set(filteredNodes.map((n) => n.id))
  const filteredEdges = network ? network.edges.filter((e) => filteredIds.has(e.source) && filteredIds.has(e.target)) : []

  return (
    <Layout>
      <h1 className="page-title">Author Collaboration Network</h1>
      <p className="page-subtitle">Each node is an author; each edge is a co-authorship on a shared paper.</p>

      <input
        className="input-field max-w-xs mt-5 mb-4"
        placeholder="Search author…"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 card h-[550px] p-2">
          {network ? <CollaborationGraph nodes={filteredNodes} edges={filteredEdges} /> : <p className="text-slate-500 p-4">Loading…</p>}
        </div>
        <div className="space-y-6">
          <div className="card">
            <h2 className="font-semibold text-navy-900 mb-2">Most Collaborative Authors</h2>
            <ul className="text-sm space-y-1">
              {summary?.most_collaborative_authors.map((a) => (
                <li key={a.author_id} className="flex justify-between"><span>{a.name}</span><span className="text-accent-blue font-medium">{a.collaborator_count}</span></li>
              ))}
            </ul>
          </div>
          <div className="card">
            <h2 className="font-semibold text-navy-900 mb-2">Largest Collaboration Groups</h2>
            {summary?.largest_collaboration_groups.map((g, idx) => (
              <div key={idx} className="mb-3 text-sm">
                <p className="font-medium text-navy-800">Group of {g.group_size}</p>
                <p className="text-slate-600">{g.authors.join(', ')}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Layout>
  )
}
