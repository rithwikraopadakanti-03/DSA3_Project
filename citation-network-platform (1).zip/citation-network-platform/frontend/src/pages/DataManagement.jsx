import { useEffect, useState } from 'react'
import Layout from '../components/Layout.jsx'
import api from '../services/api.js'

export default function DataManagement() {
  const [file, setFile] = useState(null)
  const [validation, setValidation] = useState(null)
  const [importResult, setImportResult] = useState(null)
  const [stats, setStats] = useState(null)
  const [error, setError] = useState(null)
  const [busy, setBusy] = useState(false)

  const loadStats = () => api.getDatasetStats().then(setStats)
  useEffect(loadStats, [])

  const handleFile = async (e) => {
    const f = e.target.files[0]
    setFile(f)
    setValidation(null)
    setImportResult(null)
    setError(null)
    if (!f) return
    setBusy(true)
    try {
      const res = await api.validateDataset(f)
      setValidation(res)
    } catch (err) {
      setError(err.response?.data?.detail || 'Validation failed')
    }
    setBusy(false)
  }

  const handleImport = async () => {
    if (!file) return
    setBusy(true)
    try {
      const res = await api.importDataset(file)
      setImportResult(res)
      loadStats()
    } catch (err) {
      setError(err.response?.data?.detail || 'Import failed')
    }
    setBusy(false)
  }

  const handleDelete = async () => {
    if (!confirm('This will permanently delete all papers, authors, and citations. Continue?')) return
    setBusy(true)
    await api.deleteDataset()
    setStats({ papers: 0, authors: 0, citations: 0 })
    setBusy(false)
  }

  return (
    <Layout>
      <h1 className="page-title">Data Management</h1>
      <p className="page-subtitle">Import, validate, and manage the citation dataset (CSV or JSON).</p>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
        <div className="card">
          <h2 className="font-semibold text-navy-900 mb-3">Import Dataset</h2>
          <p className="text-xs text-slate-500 mb-3">
            Expected CSV columns: <code>paper_id, title, authors, year, abstract, references</code>
            <br />
            <code>authors</code> and <code>references</code> are semicolon-separated (references = cited paper_ids).
          </p>
          <input type="file" accept=".csv,.json" onChange={handleFile} className="text-sm mb-3" />
          {error && <p className="text-accent-red text-sm mb-3">{error}</p>}
          {validation && (
            <div className="text-sm bg-green-50 border border-green-200 rounded-lg p-3 mb-3">
              ✓ Valid file — {validation.row_count} rows, columns: {validation.columns.join(', ')}
            </div>
          )}
          <div className="flex gap-3">
            <button className="btn-primary" disabled={!validation || busy} onClick={handleImport}>
              {busy ? 'Working…' : 'Import Dataset'}
            </button>
            <button className="btn-secondary" disabled={busy} onClick={handleDelete}>Delete Dataset</button>
          </div>
          {importResult && (
            <p className="text-sm text-green-700 mt-3">✓ {importResult.message} ({importResult.imported_papers} papers)</p>
          )}
        </div>

        <div className="card">
          <h2 className="font-semibold text-navy-900 mb-3">Current Dataset Statistics</h2>
          {stats ? (
            <div className="grid grid-cols-3 gap-4 text-center">
              <div><p className="text-2xl font-bold text-accent-blue">{stats.papers}</p><p className="text-xs text-slate-500">Papers</p></div>
              <div><p className="text-2xl font-bold text-accent-blue">{stats.authors}</p><p className="text-xs text-slate-500">Authors</p></div>
              <div><p className="text-2xl font-bold text-accent-red">{stats.citations}</p><p className="text-xs text-slate-500">Citations</p></div>
            </div>
          ) : <p className="text-slate-500 text-sm">Loading…</p>}
          <p className="text-xs text-slate-500 mt-4">
            To reload the bundled sample dataset (40 demo papers, 5 research clusters), run
            <code className="block bg-slate-100 rounded px-2 py-1 mt-1">python -m data.seed_data</code>
            from the <code>backend/</code> directory.
          </p>
        </div>
      </div>
    </Layout>
  )
}
