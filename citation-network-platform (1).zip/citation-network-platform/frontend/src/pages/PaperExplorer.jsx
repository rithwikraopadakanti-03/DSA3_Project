import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import Layout from '../components/Layout.jsx'
import api from '../services/api.js'

export default function PaperExplorer() {
  const [papers, setPapers] = useState([])
  const [search, setSearch] = useState('')
  const [author, setAuthor] = useState('')
  const [year, setYear] = useState('')
  const [sortBy, setSortBy] = useState('citations')
  const [loading, setLoading] = useState(true)

  const load = () => {
    setLoading(true)
    api
      .getPapers({
        search: search || undefined,
        author: author || undefined,
        year: year || undefined,
        sort_by: sortBy,
      })
      .then((d) => {
        setPapers(d)
        setLoading(false)
      })
  }

  useEffect(() => { load() }, [sortBy]) // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <Layout>
      <h1 className="page-title">Paper Explorer</h1>
      <p className="page-subtitle">Search and filter the citation database.</p>

      <div className="flex flex-wrap gap-3 mt-5 mb-4">
        <input className="input-field max-w-xs" placeholder="Search title or abstract…" value={search} onChange={(e) => setSearch(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && load()} />
        <input className="input-field max-w-[180px]" placeholder="Filter by author…" value={author} onChange={(e) => setAuthor(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && load()} />
        <input className="input-field max-w-[120px]" placeholder="Year" type="number" value={year} onChange={(e) => setYear(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && load()} />
        <select className="input-field max-w-[180px]" value={sortBy} onChange={(e) => setSortBy(e.target.value)}>
          <option value="citations">Sort: Citations</option>
          <option value="pagerank">Sort: PageRank</option>
          <option value="title">Sort: Title (A–Z)</option>
          <option value="year">Sort: Year</option>
        </select>
        <button className="btn-primary" onClick={load}>Search</button>
      </div>

      <div className="card overflow-x-auto">
        <table className="table-base">
          <thead>
            <tr>
              <th>Title</th>
              <th>Authors</th>
              <th>Year</th>
              <th>Citations</th>
              <th>PageRank</th>
              <th>Community</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={7} className="text-center text-slate-500 py-6">Loading…</td></tr>
            ) : papers.length === 0 ? (
              <tr><td colSpan={7} className="text-center text-slate-500 py-6">No papers match your filters.</td></tr>
            ) : (
              papers.map((p) => (
                <tr key={p.id}>
                  <td className="max-w-xs truncate font-medium">{p.title}</td>
                  <td className="text-slate-600">{p.authors.join(', ')}</td>
                  <td>{p.year}</td>
                  <td>{p.citation_count}</td>
                  <td>{p.pagerank_score?.toFixed(4)}</td>
                  <td>{p.community_id ?? '—'}</td>
                  <td><Link to={`/papers/${p.id}`} className="text-accent-blue hover:underline font-medium">View Details</Link></td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </Layout>
  )
}
