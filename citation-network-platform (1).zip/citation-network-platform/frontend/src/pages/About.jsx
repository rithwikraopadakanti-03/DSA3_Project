import Layout from '../components/Layout.jsx'

export default function About() {
  return (
    <Layout>
      <h1 className="page-title">About This Project</h1>
      <p className="page-subtitle">Citation-Network Analytics Platform — Data Structures and Algorithms-3 (25CS2103E)</p>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
        <div className="card">
          <h2 className="font-semibold text-navy-900 mb-2">Project Overview</h2>
          <p className="text-sm text-navy-800">
            The Citation-Network Analytics Platform models research papers and their citation relationships as a
            directed graph — papers are nodes, citations are edges — and applies classic graph algorithms to surface
            insight from that structure: traversal, shortest paths, influence ranking, and community structure.
          </p>
        </div>
        <div className="card">
          <h2 className="font-semibold text-navy-900 mb-2">Problem Statement</h2>
          <p className="text-sm text-navy-800">
            Manually tracing how research areas evolve, which papers are foundational, and how authors collaborate
            is impractical at scale. This platform automates that analysis using graph traversal, ranking, and
            clustering algorithms over a citation dataset.
          </p>
        </div>
        <div className="card">
          <h2 className="font-semibold text-navy-900 mb-2">Objectives</h2>
          <ul className="text-sm text-navy-800 list-disc list-inside space-y-1">
            <li>Represent citation relationships as a directed graph</li>
            <li>Implement BFS and DFS traversal and citation path-finding</li>
            <li>Rank papers by influence using PageRank</li>
            <li>Detect research communities via modularity-based clustering</li>
            <li>Visualize the citation and author-collaboration networks interactively</li>
          </ul>
        </div>
        <div className="card">
          <h2 className="font-semibold text-navy-900 mb-2">Algorithms Used</h2>
          <ul className="text-sm text-navy-800 list-disc list-inside space-y-1">
            <li>Breadth-First Search (queue-based)</li>
            <li>Depth-First Search (explicit stack)</li>
            <li>PageRank (power iteration)</li>
            <li>Greedy Modularity Community Detection</li>
          </ul>
        </div>
        <div className="card">
          <h2 className="font-semibold text-navy-900 mb-2">Technology Stack</h2>
          <ul className="text-sm text-navy-800 list-disc list-inside space-y-1">
            <li>Frontend: React, Tailwind CSS, Cytoscape.js, Recharts</li>
            <li>Backend: Python, FastAPI</li>
            <li>Database: SQLite</li>
            <li>Graph processing: NetworkX, Pandas, NumPy</li>
          </ul>
        </div>
        <div className="card">
          <h2 className="font-semibold text-navy-900 mb-2">Future Scope</h2>
          <ul className="text-sm text-navy-800 list-disc list-inside space-y-1">
            <li>Larger, continuously updated research-paper datasets</li>
            <li>Improved visualization for large-scale citation networks</li>
            <li>More advanced graph-analysis techniques</li>
            <li>Deeper author-collaboration analysis</li>
            <li>Integration with external research databases</li>
          </ul>
        </div>
      </div>

      <div className="card mt-6">
        <h2 className="font-semibold text-navy-900 mb-3">Project Details</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
          <div><p className="text-slate-500">Course</p><p className="font-medium">Data Structures and Algorithms - 3 (25CS2103E)</p></div>
          <div><p className="text-slate-500">Team Number</p><p className="font-medium">16</p></div>
          <div><p className="text-slate-500">Section</p><p className="font-medium">13</p></div>
          <div><p className="text-slate-500">Academic Year</p><p className="font-medium">2026–2027</p></div>
        </div>
        <div className="mt-4">
          <p className="text-slate-500 text-sm mb-1">Team Members</p>
          <p className="text-sm font-medium">Sai Ajith Reddy · P. Rithwik Rao · P. Likith Kumar</p>
        </div>
        <div className="mt-3">
          <p className="text-slate-500 text-sm mb-1">Guide</p>
          <p className="text-sm font-medium">Dr. Dyuti Benerjee</p>
        </div>
      </div>
    </Layout>
  )
}
