import { useEffect, useState } from 'react'
import Layout from '../components/Layout.jsx'
import api from '../services/api.js'

export default function Authors() {
  const [authors, setAuthors] = useState([])
  const [search, setSearch] = useState('')
  const [selected, setSelected] = useState(null)

  const load = (q) => api.getAuthors(q ? { search: q } : undefined).then(setAuthors)

  useEffect(() => { load() }, [])

  const openAuthor = (id) => api.getAuthor(id).then(setSelected)

  return (
    <Layout>
      <h1 className="page-title">Authors</h1>
      <p className="page-subtitle">Publication and citation statistics per author.</p>

      <input
        className="input-field max-w-xs mt-5 mb-4"
        placeholder="Search author…"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        onKeyDown={(e) => e.key === 'Enter' && load(search)}
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 card overflow-x-auto">
          <table className="table-base">
            <thead>
              <tr><th>Author</th><th>Publications</th><th>Total Citations</th><th>Avg Citations</th><th>Most Cited Paper</th></tr>
            </thead>
            <tbody>
              {authors.map((a) => (
                <tr key={a.id} className="cursor-pointer hover:bg-slate-50" onClick={() => openAuthor(a.id)}>
                  <td className="font-medium text-accent-blue">{a.name}</td>
                  <td>{a.publication_count}</td>
                  <td>{a.total_citations}</td>
                  <td>{a.avg_citations}</td>
                  <td className="max-w-xs truncate">{a.most_cited_paper || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="card">
          {!selected ? (
            <p className="text-slate-500 text-sm">Click an author to see full details, co-authors, and papers.</p>
          ) : (
            <div className="text-sm space-y-3">
              <h2 className="font-bold text-navy-900">{selected.name}</h2>
              <div className="flex gap-4 text-xs">
                <span><strong>{selected.publication_count}</strong> papers</span>
                <span><strong>{selected.total_citations}</strong> citations</span>
              </div>
              <div>
                <p className="font-semibold text-navy-900 mb-1">Co-authors</p>
                <p className="text-navy-700">{selected.coauthors.map((c) => c.name).join(', ') || 'None'}</p>
              </div>
              <div>
                <p className="font-semibold text-navy-900 mb-1">Papers</p>
                <ul className="list-disc list-inside text-navy-700">
                  {selected.papers.map((p) => <li key={p.id}>{p.title} ({p.citation_count} citations)</li>)}
                </ul>
              </div>
            </div>
          )}
        </div>
      </div>
    </Layout>
  )
}
