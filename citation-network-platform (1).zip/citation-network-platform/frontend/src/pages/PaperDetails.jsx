import { useEffect, useState } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import Layout from '../components/Layout.jsx'
import api from '../services/api.js'

export default function PaperDetails() {
  const { id } = useParams()
  const navigate = useNavigate()
  const [paper, setPaper] = useState(null)

  useEffect(() => {
    api.getPaper(Number(id)).then(setPaper)
  }, [id])

  if (!paper) return <Layout><p className="text-slate-500">Loading paper…</p></Layout>

  return (
    <Layout>
      <button onClick={() => navigate(-1)} className="text-sm text-accent-blue mb-4 hover:underline">&larr; Back</button>
      <h1 className="page-title">{paper.title}</h1>
      <p className="page-subtitle">{paper.authors.join(', ')} · {paper.year} · DOI {paper.doi}</p>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="card">
            <h2 className="font-semibold text-navy-900 mb-2">Abstract</h2>
            <p className="text-sm text-navy-800 leading-relaxed">{paper.abstract}</p>
          </div>

          <div className="card">
            <h2 className="font-semibold text-navy-900 mb-2">References ({paper.references.length})</h2>
            <ul className="text-sm space-y-1">
              {paper.references.map((r) => (
                <li key={r.id}><Link to={`/papers/${r.id}`} className="text-navy-800 hover:text-accent-blue">{r.title}</Link></li>
              ))}
              {paper.references.length === 0 && <p className="text-slate-500">This paper does not cite any others in the dataset.</p>}
            </ul>
          </div>

          <div className="card">
            <h2 className="font-semibold text-navy-900 mb-2">Cited By ({paper.cited_by.length})</h2>
            <ul className="text-sm space-y-1">
              {paper.cited_by.map((r) => (
                <li key={r.id}><Link to={`/papers/${r.id}`} className="text-navy-800 hover:text-accent-blue">{r.title}</Link></li>
              ))}
              {paper.cited_by.length === 0 && <p className="text-slate-500">No papers in the dataset cite this one yet.</p>}
            </ul>
          </div>
        </div>

        <div className="space-y-6">
          <div className="card space-y-2 text-sm">
            <div className="flex justify-between"><span className="text-slate-500">Citation Count</span><span className="font-semibold">{paper.citation_count}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">PageRank Score</span><span className="font-semibold">{paper.pagerank_score?.toFixed(4)}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Community</span><span className="font-semibold">{paper.community_id ?? '—'}</span></div>
          </div>
          <div className="card space-y-2">
            <Link to="/network" className="btn-secondary block text-center">Explore Network</Link>
            <Link to="/citation-paths" className="btn-secondary block text-center">Find Citation Path</Link>
            <Link to="/bfs" className="btn-secondary block text-center">Run BFS</Link>
            <Link to="/dfs" className="btn-secondary block text-center">Run DFS</Link>
          </div>
        </div>
      </div>
    </Layout>
  )
}
