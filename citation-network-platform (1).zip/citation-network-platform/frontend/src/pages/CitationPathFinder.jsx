import { useEffect, useState } from 'react'
import Layout from '../components/Layout.jsx'
import CitationGraph from '../graph/CitationGraph.jsx'
import api from '../services/api.js'

export default function CitationPathFinder() {
  const [papers, setPapers] = useState([])
  const [network, setNetwork] = useState(null)
  const [startId, setStartId] = useState('')
  const [targetId, setTargetId] = useState('')
  const [algorithm, setAlgorithm] = useState('bfs')
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    api.getPapers({ sort_by: 'title' }).then(setPapers)
    api.getNetwork().then(setNetwork)
  }, [])

  const titleOf = (id) => papers.find((p) => p.id === Number(id))?.title || id

  const findPath = async () => {
    if (!startId || !targetId) return
    setLoading(true)
    const res = await api.findCitationPath(Number(startId), Number(targetId), algorithm)
    setResult(res)
    setLoading(false)
  }

  return (
    <Layout>
      <h1 className="page-title">Citation Path Finder</h1>
      <p className="page-subtitle">Find a citation path between two papers using BFS or DFS.</p>

      <div className="card mt-5 flex flex-wrap items-end gap-4">
        <div>
          <label className="text-xs text-slate-500 font-medium block mb-1">Start Paper</label>
          <select className="input-field min-w-[240px]" value={startId} onChange={(e) => setStartId(e.target.value)}>
            <option value="">Select a paper…</option>
            {papers.map((p) => <option key={p.id} value={p.id}>{p.title}</option>)}
          </select>
        </div>
        <div>
          <label className="text-xs text-slate-500 font-medium block mb-1">Target Paper</label>
          <select className="input-field min-w-[240px]" value={targetId} onChange={(e) => setTargetId(e.target.value)}>
            <option value="">Select a paper…</option>
            {papers.map((p) => <option key={p.id} value={p.id}>{p.title}</option>)}
          </select>
        </div>
        <div>
          <label className="text-xs text-slate-500 font-medium block mb-1">Algorithm</label>
          <div className="flex gap-1">
            <button onClick={() => setAlgorithm('bfs')} className={`px-3 py-2 rounded-lg text-sm font-medium border ${algorithm === 'bfs' ? 'bg-accent-blue text-white border-accent-blue' : 'border-slate-300 text-navy-800'}`}>BFS</button>
            <button onClick={() => setAlgorithm('dfs')} className={`px-3 py-2 rounded-lg text-sm font-medium border ${algorithm === 'dfs' ? 'bg-accent-blue text-white border-accent-blue' : 'border-slate-300 text-navy-800'}`}>DFS</button>
          </div>
        </div>
        <button className="btn-primary" disabled={!startId || !targetId || loading} onClick={findPath}>
          {loading ? 'Finding…' : 'Find Path'}
        </button>
      </div>

      {result && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
          <div className="card lg:col-span-1">
            {result.path_found ? (
              <>
                <h2 className="font-semibold text-navy-900 mb-3">Path Found ({result.algorithm})</h2>
                <div className="space-y-1 text-sm">
                  {result.path.map((id, idx) => (
                    <div key={id}>
                      <p className="text-navy-800">{titleOf(id)}</p>
                      {idx < result.path.length - 1 && <p className="text-slate-400 text-center">↓</p>}
                    </div>
                  ))}
                </div>
                <div className="mt-4 pt-4 border-t border-slate-200 text-sm space-y-1">
                  <p><strong>Path Length:</strong> {result.path_length}</p>
                  <p><strong>Nodes Visited:</strong> {result.nodes_visited}</p>
                  <p><strong>Execution Time:</strong> {result.execution_time_ms} ms</p>
                </div>
              </>
            ) : (
              <p className="text-slate-600">
                No citation path found from the start paper to the target ({result.nodes_visited} nodes explored in {result.execution_time_ms} ms).
              </p>
            )}
          </div>
          <div className="lg:col-span-2 card h-[500px] p-2">
            {network && (
              <CitationGraph
                nodes={network.nodes}
                edges={network.edges}
                highlightPath={result.path_found ? result.path : null}
              />
            )}
          </div>
        </div>
      )}
    </Layout>
  )
}
