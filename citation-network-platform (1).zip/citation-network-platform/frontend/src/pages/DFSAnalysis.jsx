import { useEffect, useState } from 'react'
import Layout from '../components/Layout.jsx'
import CitationGraph from '../graph/CitationGraph.jsx'
import AlgorithmDetailsPanel from '../components/AlgorithmDetailsPanel.jsx'
import api from '../services/api.js'

export default function DFSAnalysis() {
  const [papers, setPapers] = useState([])
  const [network, setNetwork] = useState(null)
  const [startId, setStartId] = useState('')
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    api.getPapers({ sort_by: 'title' }).then(setPapers)
    api.getNetwork().then(setNetwork)
  }, [])

  const run = async () => {
    if (!startId) return
    setLoading(true)
    const res = await api.runDFS(Number(startId))
    setResult(res)
    setLoading(false)
  }

  return (
    <Layout>
      <h1 className="page-title">DFS Analysis</h1>
      <p className="page-subtitle">Depth-first traversal of the citation graph using an explicit stack.</p>

      <div className="card mt-5 flex flex-wrap items-end gap-4">
        <div>
          <label className="text-xs text-slate-500 font-medium block mb-1">Starting Paper</label>
          <select className="input-field min-w-[280px]" value={startId} onChange={(e) => setStartId(e.target.value)}>
            <option value="">Select a paper…</option>
            {papers.map((p) => <option key={p.id} value={p.id}>{p.title}</option>)}
          </select>
        </div>
        <button className="btn-primary" disabled={!startId || loading} onClick={run}>{loading ? 'Running…' : 'Run DFS'}</button>
      </div>

      {result && (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
            <div className="card"><p className="text-xs text-slate-500">Nodes Visited</p><p className="text-2xl font-bold text-accent-red">{result.nodes_visited}</p></div>
            <div className="card"><p className="text-xs text-slate-500">Edges Explored</p><p className="text-2xl font-bold text-accent-red">{result.edges_explored}</p></div>
            <div className="card"><p className="text-xs text-slate-500">Max Depth</p><p className="text-2xl font-bold text-accent-red">{result.max_depth}</p></div>
            <div className="card"><p className="text-xs text-slate-500">Execution Time</p><p className="text-2xl font-bold text-accent-red">{result.execution_time_ms} ms</p></div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
            <div className="card lg:col-span-1 max-h-[500px] overflow-y-auto">
              <h2 className="font-semibold text-navy-900 mb-3">Traversal Order</h2>
              <ol className="text-sm text-navy-800 list-decimal list-inside space-y-1">
                {result.traversal_order.map((id) => (
                  <li key={id}>{result.titles[id] || id} <span className="text-slate-400">(depth {result.depth_at[id]})</span></li>
                ))}
              </ol>
            </div>
            <div className="lg:col-span-2 card h-[500px] p-2">
              {network && (
                <CitationGraph nodes={network.nodes} edges={network.edges} highlightSet={new Set(result.traversal_order)} />
              )}
            </div>
          </div>

          <div className="mt-6">
            <AlgorithmDetailsPanel
              name="Depth-First Search"
              purpose="Explore as far as possible along each citation branch before backtracking"
              input="Starting paper node"
              output="Traversal order, depth of each node, visited/explored counts"
              dataStructure="Stack (LIFO, explicit)"
              timeComplexity="O(V + E)"
              spaceComplexity="O(V)"
            />
          </div>
        </>
      )}
    </Layout>
  )
}
