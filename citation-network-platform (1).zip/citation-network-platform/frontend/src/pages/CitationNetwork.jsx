import { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import Layout from '../components/Layout.jsx'
import CitationGraph from '../graph/CitationGraph.jsx'
import api from '../services/api.js'

export default function CitationNetwork() {
  const [network, setNetwork] = useState(null)
  const [search, setSearch] = useState('')
  const [communityFilter, setCommunityFilter] = useState('all')
  const [selectedNode, setSelectedNode] = useState(null)
  const [paperDetail, setPaperDetail] = useState(null)

  useEffect(() => {
    api.getNetwork().then(setNetwork)
  }, [])

  const communities = useMemo(() => {
    if (!network) return []
    return [...new Set(network.nodes.map((n) => n.community).filter((c) => c !== null && c !== undefined))].sort()
  }, [network])

  const filteredNodes = useMemo(() => {
    if (!network) return []
    return network.nodes.filter((n) => {
      const matchesSearch = !search || n.label.toLowerCase().includes(search.toLowerCase())
      const matchesCommunity = communityFilter === 'all' || n.community === Number(communityFilter)
      return matchesSearch && matchesCommunity
    })
  }, [network, search, communityFilter])

  const filteredEdges = useMemo(() => {
    if (!network) return []
    const ids = new Set(filteredNodes.map((n) => n.id))
    return network.edges.filter((e) => ids.has(e.source) && ids.has(e.target))
  }, [network, filteredNodes])

  const handleNodeClick = (nodeId) => {
    setSelectedNode(nodeId)
    api.getPaper(Number(nodeId)).then(setPaperDetail)
  }

  return (
    <Layout>
      <h1 className="page-title">Citation Network</h1>
      <p className="page-subtitle">Each node is a paper; each directed edge is a citation. Click a node to inspect it.</p>

      <div className="flex flex-wrap gap-3 mt-5 mb-4">
        <input
          className="input-field max-w-xs"
          placeholder="Search paper title…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <select className="input-field max-w-[180px]" value={communityFilter} onChange={(e) => setCommunityFilter(e.target.value)}>
          <option value="all">All communities</option>
          {communities.map((c) => (
            <option key={c} value={c}>Community {c}</option>
          ))}
        </select>
        <button className="btn-secondary" onClick={() => { setSearch(''); setCommunityFilter('all'); setSelectedNode(null); setPaperDetail(null) }}>
          Reset
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 card h-[600px] p-2">
          {network ? (
            <CitationGraph nodes={filteredNodes} edges={filteredEdges} onNodeClick={handleNodeClick} />
          ) : (
            <p className="text-slate-500 p-4">Loading network…</p>
          )}
        </div>

        <div className="card h-[600px] overflow-y-auto">
          {!paperDetail ? (
            <p className="text-slate-500 text-sm">Click a paper node to see its details here.</p>
          ) : (
            <div className="text-sm space-y-3">
              <h2 className="font-bold text-navy-900 leading-snug">{paperDetail.title}</h2>
              <p className="text-slate-500">{paperDetail.authors.join(', ')} · {paperDetail.year}</p>
              <p className="text-navy-800">{paperDetail.abstract}</p>
              <div className="flex gap-4 text-xs">
                <span><strong>{paperDetail.citation_count}</strong> citations</span>
                <span><strong>{paperDetail.pagerank_score?.toFixed(4)}</strong> PageRank</span>
                <span>Community {paperDetail.community_id ?? '—'}</span>
              </div>
              <div>
                <p className="font-semibold text-navy-900">References ({paperDetail.references.length})</p>
                <ul className="list-disc list-inside text-navy-700">
                  {paperDetail.references.map((r) => <li key={r.id}>{r.title}</li>)}
                </ul>
              </div>
              <div>
                <p className="font-semibold text-navy-900">Cited By ({paperDetail.cited_by.length})</p>
                <ul className="list-disc list-inside text-navy-700">
                  {paperDetail.cited_by.map((r) => <li key={r.id}>{r.title}</li>)}
                </ul>
              </div>
              <Link to={`/papers/${paperDetail.id}`} className="btn-primary inline-block mt-2">View Full Details</Link>
            </div>
          )}
        </div>
      </div>
    </Layout>
  )
}
