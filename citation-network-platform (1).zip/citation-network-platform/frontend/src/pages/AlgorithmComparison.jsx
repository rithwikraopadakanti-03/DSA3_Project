import Layout from '../components/Layout.jsx'

const ROWS = [
  { name: 'BFS', purpose: 'Find shortest citation path / explore level by level', structure: 'Queue (FIFO)', method: 'Level-by-level', time: 'O(V + E)', space: 'O(V)' },
  { name: 'DFS', purpose: 'Explore deep citation chains / detect any path', structure: 'Stack (LIFO)', method: 'Depth-first, backtracking', time: 'O(V + E)', space: 'O(V)' },
  { name: 'PageRank', purpose: 'Rank papers by structural importance in the citation graph', structure: 'Sparse matrix / adjacency', method: 'Power iteration', time: 'O(k·(V + E))', space: 'O(V)' },
  { name: 'Community Detection', purpose: 'Group closely-connected papers into research communities', structure: 'Undirected graph, priority queue (modularity gain)', method: 'Greedy modularity maximization', time: '≈ O(E·V) worst case (sparse graphs)', space: 'O(V + E)' },
]

export default function AlgorithmComparison() {
  return (
    <Layout>
      <h1 className="page-title">Algorithm Comparison</h1>
      <p className="page-subtitle">
        BFS, DFS, PageRank, and Community Detection compared side by side. V = number of papers (vertices), E = number of citations (edges).
      </p>

      <div className="card mt-6 overflow-x-auto">
        <table className="table-base">
          <thead>
            <tr>
              <th>Algorithm</th>
              <th>Purpose</th>
              <th>Data Structure</th>
              <th>Method</th>
              <th>Time Complexity</th>
              <th>Space Complexity</th>
            </tr>
          </thead>
          <tbody>
            {ROWS.map((r) => (
              <tr key={r.name}>
                <td className="font-semibold">{r.name}</td>
                <td className="max-w-xs">{r.purpose}</td>
                <td>{r.structure}</td>
                <td>{r.method}</td>
                <td className="font-mono text-xs">{r.time}</td>
                <td className="font-mono text-xs">{r.space}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
        <div className="card">
          <h2 className="font-semibold text-navy-900 mb-2">Graph Traversal (BFS / DFS)</h2>
          <p className="text-sm text-navy-800">
            Both traversals visit every reachable paper and follow every outgoing citation edge at most once,
            which is where the O(V + E) bound comes from — V for visiting each node, E for exploring each edge.
            BFS uses a queue to expand outward in citation "layers," which guarantees the shortest path when one is
            found. DFS uses a stack to follow one citation chain as deep as possible before backtracking, which finds
            *a* path (not necessarily the shortest) but is often faster to reach a distant paper.
          </p>
        </div>
        <div className="card">
          <h2 className="font-semibold text-navy-900 mb-2">PageRank vs. Raw Citation Count</h2>
          <p className="text-sm text-navy-800">
            PageRank evaluates importance based on the structure of the citation network rather than simply counting
            citations — a paper cited a few times by highly influential papers can outrank a paper cited many times
            by obscure ones. It's computed via power iteration over the graph's adjacency structure until scores
            converge.
          </p>
        </div>
      </div>
    </Layout>
  )
}
