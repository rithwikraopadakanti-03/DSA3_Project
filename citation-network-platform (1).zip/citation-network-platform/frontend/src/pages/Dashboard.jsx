import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'
import Layout from '../components/Layout.jsx'
import StatCard from '../components/StatCard.jsx'
import api from '../services/api.js'

const COLORS = ['#2563eb', '#dc2626', '#059669', '#d97706', '#7c3aed', '#0891b2']

export default function Dashboard() {
  const [stats, setStats] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    api.getStatistics().then((d) => {
      setStats(d)
      setLoading(false)
    })
  }, [])

  if (loading) return <Layout><p className="text-slate-500">Loading dashboard…</p></Layout>
  if (!stats) return <Layout><p className="text-slate-500">No data available. Try importing a dataset.</p></Layout>

  return (
    <Layout>
      <h1 className="page-title">Citation-Network Analytics Platform</h1>
      <p className="page-subtitle">
        Explore research papers, citation relationships, influential papers, communities, and authors.
      </p>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mt-6">
        <StatCard label="Total Papers" value={stats.total_papers} />
        <StatCard label="Total Citations" value={stats.total_citations} accent="red" />
        <StatCard label="Total Authors" value={stats.total_authors} />
        <StatCard label="Communities" value={stats.total_communities || '—'} accent="red" />
        <StatCard label="Avg Citations / Paper" value={stats.avg_citations_per_paper} />
        <div className="card">
          <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">Most Influential</p>
          <p className="text-sm font-bold mt-2 text-navy-900 leading-snug">
            {stats.most_influential_paper?.title || 'Run PageRank first'}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
        <div className="card">
          <h2 className="font-semibold text-navy-900 mb-3">Papers by Year</h2>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={stats.papers_by_year}>
              <XAxis dataKey="year" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="c" name="Papers" fill="#2563eb" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="card">
          <h2 className="font-semibold text-navy-900 mb-3">Community Sizes</h2>
          {stats.community_sizes?.length ? (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie
                  data={stats.community_sizes}
                  dataKey="c"
                  nameKey="community_id"
                  outerRadius={80}
                  label={(entry) => `C${entry.community_id}`}
                >
                  {stats.community_sizes.map((_, i) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <p className="text-sm text-slate-500">
              Run community detection on the{' '}
              <Link to="/communities" className="text-accent-blue underline">Communities</Link> page to populate this chart.
            </p>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
        <div className="card">
          <h2 className="font-semibold text-navy-900 mb-3">Top Influential Papers</h2>
          <ul className="space-y-2 text-sm">
            {stats.top_influential_papers.map((p) => (
              <li key={p.id} className="flex justify-between gap-2">
                <Link to={`/papers/${p.id}`} className="text-navy-800 hover:text-accent-blue truncate">{p.title}</Link>
                <span className="text-accent-blue font-medium shrink-0">{p.pagerank_score?.toFixed(3)}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="card">
          <h2 className="font-semibold text-navy-900 mb-3">Most Cited Papers</h2>
          <ul className="space-y-2 text-sm">
            {stats.most_cited_papers.map((p) => (
              <li key={p.id} className="flex justify-between gap-2">
                <Link to={`/papers/${p.id}`} className="text-navy-800 hover:text-accent-blue truncate">{p.title}</Link>
                <span className="text-accent-red font-medium shrink-0">{p.citation_count}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="card">
          <h2 className="font-semibold text-navy-900 mb-3">Recent Papers</h2>
          <ul className="space-y-2 text-sm">
            {stats.recent_papers.map((p) => (
              <li key={p.id} className="flex justify-between gap-2">
                <Link to={`/papers/${p.id}`} className="text-navy-800 hover:text-accent-blue truncate">{p.title}</Link>
                <span className="text-slate-500 shrink-0">{p.year}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="card mt-6">
        <h2 className="font-semibold text-navy-900 mb-3">Quick Analysis</h2>
        <div className="flex flex-wrap gap-3">
          <Link to="/bfs" className="btn-secondary">Run BFS</Link>
          <Link to="/dfs" className="btn-secondary">Run DFS</Link>
          <Link to="/pagerank" className="btn-secondary">Calculate PageRank</Link>
          <Link to="/communities" className="btn-secondary">Detect Communities</Link>
          <Link to="/citation-paths" className="btn-secondary">Find Citation Path</Link>
        </div>
      </div>
    </Layout>
  )
}
