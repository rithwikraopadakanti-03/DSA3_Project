# Citation-Network Analytics Platform

A full-stack academic analytics platform that models research papers and their
citation relationships as a directed graph — **paper = node, citation = directed
edge** — and applies classic graph algorithms to explore it: BFS/DFS traversal,
citation path-finding, PageRank, and community detection.

Built for **Data Structures and Algorithms-3 (25CS2103E)**, Team 16, Section 13.

> The bundled dataset is **fictional/demo data**, generated for coursework so
> that BFS, DFS, PageRank, and community detection all produce interesting,
> non-trivial results out of the box (40 papers, 20 authors, 113 citations
> across 5 research clusters).

---

## 1. Features

- Interactive citation-network graph (Cytoscape.js) with zoom, pan, search,
  and community-colored nodes
- Paper Explorer with search/filter/sort and a full Paper Details page
- Citation Path Finder (BFS or DFS) with the discovered path highlighted on
  the graph
- Dedicated BFS and DFS pages showing traversal order, levels/depth, nodes
  visited, edges explored, and execution time — computed live from the graph,
  not hard-coded
- PageRank ranking with a distribution chart and a Top 10 / Top 20 table
- Research community detection (greedy modularity) with per-community stats
- Author analytics and an author collaboration graph
- Data Management page to import your own CSV/JSON citation datasets
- An Algorithm Comparison page and an "Algorithm Details" panel (purpose,
  data structure, time/space complexity) on every algorithm page

## 2. Technology Stack

| Layer | Tech |
|---|---|
| Frontend | React, React Router, Tailwind CSS, Cytoscape.js, Recharts, Axios |
| Backend | Python, FastAPI, Uvicorn |
| Database | SQLite |
| Graph processing | NetworkX, SciPy |
| Data processing | Pandas, NumPy |

## 3. Folder Structure

```
citation-network-platform/
├── frontend/
│   ├── src/
│   │   ├── components/      Sidebar, Layout, StatCard, AlgorithmDetailsPanel
│   │   ├── pages/            One file per page (Dashboard, BFS, PageRank, ...)
│   │   ├── graph/             Cytoscape wrappers (citation + collaboration graphs)
│   │   ├── services/api.js   Axios client for the backend API
│   │   └── App.jsx           Route definitions
│   ├── package.json
│   └── vite.config.js
│
├── backend/
│   ├── algorithms/            bfs.py, dfs.py, pagerank.py, community_detection.py
│   ├── api/                   One router per resource (papers, authors, network, ...)
│   ├── database/db.py         SQLite connection + schema
│   ├── models/schemas.py      Pydantic models
│   ├── services/graph_service.py   Builds NetworkX graphs from the DB
│   ├── data/seed_data.py      Generates + loads the sample dataset
│   ├── main.py                FastAPI app entry point
│   └── requirements.txt
│
├── sample_data/
│   ├── papers.csv              Exported sample dataset (re-importable)
│   └── authors.csv
│
├── README.md
└── .env.example
```

## 4. Setup & Running Locally

### Backend

```bash
cd backend
python -m venv venv

# Activate:
source venv/bin/activate        # macOS/Linux
venv\Scripts\activate           # Windows

pip install -r requirements.txt

# Load the sample dataset (creates citation_network.db and populates it):
python -m data.seed_data

# Start the API:
uvicorn main:app --reload --port 8000
```
The API is now running at **http://localhost:8000** (interactive docs at
`http://localhost:8000/docs`).

### Frontend

```bash
cd frontend
npm install
cp ../.env.example .env   # or create .env with VITE_API_BASE_URL=http://localhost:8000
npm run dev
```
The app is now running at **http://localhost:5173**.

> The dataset already ships pre-loaded (`backend/citation_network.db`), so the
> app works immediately — re-running `python -m data.seed_data` resets it back
> to the original sample data at any time.

## 5. API Reference

Base URL: `http://localhost:8000`

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/health` | Health check |
| GET | `/api/statistics` | Dashboard statistics (computed live) |
| GET | `/api/papers` | List/search/filter/sort papers |
| GET | `/api/papers/{id}` | Paper detail with references & cited-by |
| GET | `/api/authors` | List authors with computed stats |
| GET | `/api/authors/{id}` | Author detail with co-authors and papers |
| GET | `/api/network` | Full citation graph (nodes + edges) |
| GET | `/api/network/collaborations` | Full author-collaboration graph |
| GET | `/api/collaborations` | Collaboration summary (top authors, groups) |
| GET | `/api/communities` | Runs community detection, returns communities |
| GET | `/api/communities/{id}` | Papers in one community |
| GET | `/api/pagerank` | Runs PageRank, returns ranked papers |
| POST | `/api/bfs` | `{start_paper_id}` → BFS traversal |
| POST | `/api/dfs` | `{start_paper_id}` → DFS traversal |
| POST | `/api/citation-path` | `{start_paper_id, target_paper_id, algorithm}` → path |
| POST | `/api/import/validate` | Validate an uploaded CSV/JSON file |
| POST | `/api/import` | Import a dataset (rebuilds the citation graph) |
| DELETE | `/api/import` | Clear the dataset |
| GET | `/api/import/stats` | Current row counts |

Full interactive documentation (auto-generated by FastAPI) is available at
`/docs` while the backend is running.

## 6. How Each Algorithm Is Implemented

- **BFS** (`backend/algorithms/bfs.py`) — a `collections.deque` used as a
  FIFO queue; expands the citation graph one "level" at a time from a start
  paper. Also powers shortest citation-path finding.
- **DFS** (`backend/algorithms/dfs.py`) — an explicit stack (not recursion,
  to avoid Python's recursion limit on larger graphs); explores one citation
  chain as deep as possible before backtracking.
- **PageRank** (`backend/algorithms/pagerank.py`) — NetworkX's power-iteration
  implementation over the citation graph's adjacency structure.
- **Community Detection** (`backend/algorithms/community_detection.py`) —
  NetworkX's greedy modularity maximization (Clauset–Newman–Moore) on the
  undirected version of the citation graph.

All four operate on a live `networkx.DiGraph` rebuilt from the current SQLite
data on every request (`backend/services/graph_service.py`) — nothing is
pre-computed or faked.

DSA concepts demonstrated: graph representation (adjacency via NetworkX),
queues, stacks, BFS/DFS traversal, shortest-path search, iterative numerical
algorithms (PageRank), and greedy graph clustering (modularity).

## 7. Importing Your Own Data

CSV columns required: `paper_id, title, authors, year, abstract, references`
- `authors`: semicolon-separated names, e.g. `A. Smith;B. Jones`
- `references`: semicolon-separated `paper_id`s this paper cites, e.g. `2;5;9`

JSON: a list of objects with the same fields. Use the Data Management page to
validate before importing — it checks the required columns are present.

## 8. Demonstrating to Faculty (Suggested Flow)

1. **Dashboard** — show total papers, citations, authors, communities (all
   computed live from the database).
2. **Citation Network** — open the graph, click a paper, show its detail panel.
3. **BFS** — pick a paper, run BFS, show the level-by-level traversal and the
   highlighted nodes on the graph.
4. **DFS** — same starting paper, run DFS, show the different traversal order
   and depth.
5. **PageRank** — show the Top 10 influential papers and distribution chart.
6. **Communities** — show the detected research communities and their
   modularity score.
7. **Authors** → **Collaborations** — show author stats and the co-authorship
   graph.
8. **Citation Path Finder** — pick a start and target paper, find the path
   with BFS, show it highlighted on the graph.
9. **Algorithm Comparison** — summarize complexity and trade-offs for the
   faculty.

## 9. Future Scope

- Larger, continuously updated research-paper datasets
- Improved visualization for very large citation networks
- More advanced graph-analysis techniques (e.g. temporal citation dynamics)
- Deeper author-collaboration analysis
- Integration with external research databases (Semantic Scholar, arXiv, etc.)
