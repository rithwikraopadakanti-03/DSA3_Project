"""Pydantic request/response models."""
from pydantic import BaseModel
from typing import List, Optional


class PaperOut(BaseModel):
    id: int
    title: str
    abstract: Optional[str] = None
    year: Optional[int] = None
    doi: Optional[str] = None
    citation_count: int = 0
    pagerank_score: float = 0.0
    community_id: Optional[int] = None
    authors: List[str] = []


class PaperDetail(PaperOut):
    references: List[PaperOut] = []
    cited_by: List[PaperOut] = []


class AuthorOut(BaseModel):
    id: int
    name: str
    publication_count: int = 0
    total_citations: int = 0
    avg_citations: float = 0.0
    most_cited_paper: Optional[str] = None


class TraversalRequest(BaseModel):
    start_paper_id: int


class PathRequest(BaseModel):
    start_paper_id: int
    target_paper_id: int
    algorithm: str = "bfs"  # "bfs" or "dfs"


class ImportPayload(BaseModel):
    papers: List[dict] = []
