"""Builds and caches a NetworkX DiGraph from the SQLite citation data."""
import networkx as nx
from database.db import get_connection


def build_citation_graph() -> nx.DiGraph:
    """Paper = node, citation (source -> target) = directed edge."""
    conn = get_connection()
    graph = nx.DiGraph()

    papers = conn.execute("SELECT id, title, year, citation_count FROM papers").fetchall()
    for p in papers:
        graph.add_node(p["id"], title=p["title"], year=p["year"], citation_count=p["citation_count"])

    edges = conn.execute("SELECT source_paper_id, target_paper_id FROM citations").fetchall()
    for e in edges:
        graph.add_edge(e["source_paper_id"], e["target_paper_id"])

    conn.close()
    return graph


def build_collaboration_graph() -> nx.Graph:
    """Author = node, co-authorship on a shared paper = undirected edge (weighted by shared papers)."""
    conn = get_connection()
    graph = nx.Graph()

    authors = conn.execute("SELECT id, name FROM authors").fetchall()
    for a in authors:
        graph.add_node(a["id"], name=a["name"])

    paper_author_rows = conn.execute(
        "SELECT paper_id, author_id FROM paper_authors ORDER BY paper_id"
    ).fetchall()

    by_paper = {}
    for row in paper_author_rows:
        by_paper.setdefault(row["paper_id"], []).append(row["author_id"])

    for paper_id, author_ids in by_paper.items():
        for i in range(len(author_ids)):
            for j in range(i + 1, len(author_ids)):
                a, b = author_ids[i], author_ids[j]
                if graph.has_edge(a, b):
                    graph[a][b]["weight"] += 1
                else:
                    graph.add_edge(a, b, weight=1)

    conn.close()
    return graph
