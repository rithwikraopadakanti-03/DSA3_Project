"""Dashboard statistics endpoint — all figures computed dynamically from the DB."""
from fastapi import APIRouter
from database.db import get_connection

router = APIRouter(prefix="/api/statistics", tags=["statistics"])


@router.get("")
def get_statistics():
    conn = get_connection()

    total_papers = conn.execute("SELECT COUNT(*) c FROM papers").fetchone()["c"]
    total_citations = conn.execute("SELECT COUNT(*) c FROM citations").fetchone()["c"]
    total_authors = conn.execute("SELECT COUNT(*) c FROM authors").fetchone()["c"]
    total_communities = conn.execute("SELECT COUNT(DISTINCT community_id) c FROM papers WHERE community_id IS NOT NULL").fetchone()["c"]

    avg_citations = conn.execute("SELECT AVG(citation_count) a FROM papers").fetchone()["a"] or 0

    top_paper = conn.execute(
        "SELECT title, pagerank_score FROM papers ORDER BY pagerank_score DESC LIMIT 1"
    ).fetchone()

    papers_by_year = conn.execute(
        "SELECT year, COUNT(*) c FROM papers GROUP BY year ORDER BY year"
    ).fetchall()

    top_influential = conn.execute(
        "SELECT id, title, pagerank_score, citation_count FROM papers ORDER BY pagerank_score DESC LIMIT 5"
    ).fetchall()

    most_cited = conn.execute(
        "SELECT id, title, citation_count FROM papers ORDER BY citation_count DESC LIMIT 5"
    ).fetchall()

    recent_papers = conn.execute(
        "SELECT id, title, year FROM papers ORDER BY year DESC LIMIT 5"
    ).fetchall()

    community_sizes = conn.execute(
        "SELECT community_id, COUNT(*) c FROM papers WHERE community_id IS NOT NULL GROUP BY community_id"
    ).fetchall()

    conn.close()

    return {
        "total_papers": total_papers,
        "total_citations": total_citations,
        "total_authors": total_authors,
        "total_communities": total_communities,
        "avg_citations_per_paper": round(avg_citations, 2),
        "most_influential_paper": dict(top_paper) if top_paper else None,
        "papers_by_year": [dict(r) for r in papers_by_year],
        "top_influential_papers": [dict(r) for r in top_influential],
        "most_cited_papers": [dict(r) for r in most_cited],
        "recent_papers": [dict(r) for r in recent_papers],
        "community_sizes": [dict(r) for r in community_sizes],
    }
