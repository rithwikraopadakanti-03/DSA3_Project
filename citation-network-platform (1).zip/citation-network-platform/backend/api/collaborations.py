"""Collaboration-network summary endpoint (most collaborative authors, largest groups)."""
from fastapi import APIRouter
from services.graph_service import build_collaboration_graph
import networkx as nx

router = APIRouter(prefix="/api/collaborations", tags=["collaborations"])


@router.get("")
def collaboration_summary():
    graph = build_collaboration_graph()

    degree_sorted = sorted(graph.degree, key=lambda kv: kv[1], reverse=True)[:10]
    most_collaborative = [
        {"author_id": node_id, "name": graph.nodes[node_id]["name"], "collaborator_count": degree}
        for node_id, degree in degree_sorted
    ]

    components = sorted(nx.connected_components(graph), key=len, reverse=True)[:5]
    largest_groups = [
        {
            "group_size": len(comp),
            "authors": [graph.nodes[n]["name"] for n in comp],
        }
        for comp in components
    ]

    return {
        "total_authors": graph.number_of_nodes(),
        "total_collaboration_edges": graph.number_of_edges(),
        "most_collaborative_authors": most_collaborative,
        "largest_collaboration_groups": largest_groups,
    }
