"""Author endpoints: list with computed stats, and per-author detail."""
from fastapi import APIRouter, HTTPException, Query
from typing import Optional
from database.db import get_connection

router = APIRouter(prefix="/api/authors", tags=["authors"])


def _author_stats(conn, author_id):
    papers = conn.execute(
        """SELECT p.* FROM papers p
           JOIN paper_authors pa ON pa.paper_id = p.id
           WHERE pa.author_id = ?
           ORDER BY p.citation_count DESC""",
        (author_id,),
    ).fetchall()
    total_citations = sum(p["citation_count"] for p in papers)
    pub_count = len(papers)
    return {
        "publication_count": pub_count,
        "total_citations": total_citations,
        "avg_citations": round(total_citations / pub_count, 2) if pub_count else 0,
        "most_cited_paper": papers[0]["title"] if papers else None,
        "papers": [dict(p) for p in papers],
    }


@router.get("")
def list_authors(search: Optional[str] = Query(None)):
    conn = get_connection()
    if search:
        rows = conn.execute("SELECT * FROM authors WHERE name LIKE ?", (f"%{search}%",)).fetchall()
    else:
        rows = conn.execute("SELECT * FROM authors").fetchall()

    result = []
    for r in rows:
        stats = _author_stats(conn, r["id"])
        stats.pop("papers")
        result.append({"id": r["id"], "name": r["name"], **stats})

    result.sort(key=lambda a: a["total_citations"], reverse=True)
    conn.close()
    return result


@router.get("/{author_id}")
def get_author(author_id: int):
    conn = get_connection()
    row = conn.execute("SELECT * FROM authors WHERE id = ?", (author_id,)).fetchone()
    if not row:
        conn.close()
        raise HTTPException(status_code=404, detail="Author not found")

    stats = _author_stats(conn, author_id)

    coauthor_rows = conn.execute(
        """SELECT DISTINCT a2.id, a2.name FROM paper_authors pa1
           JOIN paper_authors pa2 ON pa1.paper_id = pa2.paper_id AND pa1.author_id != pa2.author_id
           JOIN authors a2 ON a2.id = pa2.author_id
           WHERE pa1.author_id = ?""",
        (author_id,),
    ).fetchall()

    conn.close()
    return {
        "id": row["id"],
        "name": row["name"],
        **stats,
        "coauthors": [dict(c) for c in coauthor_rows],
    }
