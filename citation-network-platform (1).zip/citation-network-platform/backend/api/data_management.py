"""
Dataset import/management endpoints.

Expected CSV columns: paper_id, title, authors, year, abstract, references
  - authors: semicolon-separated author names, e.g. "A. Smith;B. Jones"
  - references: semicolon-separated paper_id values this paper cites, e.g. "2;5;9"
JSON import expects a list of the same fields.
"""
import io
import csv
import json
import pandas as pd
from fastapi import APIRouter, UploadFile, File, HTTPException
from database.db import get_connection, reset_db

router = APIRouter(prefix="/api", tags=["data-management"])

REQUIRED_FIELDS = {"paper_id", "title", "authors", "year", "abstract", "references"}


def _parse_upload(filename: str, raw: bytes):
    if filename.endswith(".csv"):
        text = raw.decode("utf-8-sig")
        reader = csv.DictReader(io.StringIO(text))
        rows = list(reader)
    elif filename.endswith(".json"):
        rows = json.loads(raw.decode("utf-8"))
    else:
        raise HTTPException(status_code=400, detail="Only .csv and .json files are supported")

    if not rows:
        raise HTTPException(status_code=400, detail="Uploaded file contains no rows")

    missing = REQUIRED_FIELDS - set(rows[0].keys())
    if missing:
        raise HTTPException(status_code=400, detail=f"Missing required columns: {sorted(missing)}")

    return rows


@router.post("/import/validate")
async def validate_dataset(file: UploadFile = File(...)):
    raw = await file.read()
    rows = _parse_upload(file.filename, raw)
    return {"valid": True, "row_count": len(rows), "columns": list(rows[0].keys())}


@router.post("/import")
async def import_dataset(file: UploadFile = File(...)):
    raw = await file.read()
    rows = _parse_upload(file.filename, raw)

    conn = get_connection()
    id_map = {}  # dataset paper_id (string) -> DB id

    # Pass 1: insert papers + authors
    for row in rows:
        cur = conn.execute(
            "INSERT INTO papers (title, abstract, year, citation_count, pagerank_score) VALUES (?, ?, ?, 0, 0)",
            (row["title"], row.get("abstract", ""), int(row["year"]) if row.get("year") else None),
        )
        db_id = cur.lastrowid
        id_map[str(row["paper_id"])] = db_id

        author_names = [a.strip() for a in str(row.get("authors", "")).split(";") if a.strip()]
        for name in author_names:
            existing = conn.execute("SELECT id FROM authors WHERE name = ?", (name,)).fetchone()
            author_id = existing["id"] if existing else conn.execute(
                "INSERT INTO authors (name) VALUES (?)", (name,)
            ).lastrowid
            conn.execute(
                "INSERT OR IGNORE INTO paper_authors (paper_id, author_id) VALUES (?, ?)",
                (db_id, author_id),
            )

    # Pass 2: insert citations now that all papers exist
    for row in rows:
        source_db_id = id_map[str(row["paper_id"])]
        ref_ids = [r.strip() for r in str(row.get("references", "")).split(";") if r.strip()]
        for ref in ref_ids:
            target_db_id = id_map.get(ref)
            if target_db_id:
                conn.execute(
                    "INSERT OR IGNORE INTO citations (source_paper_id, target_paper_id) VALUES (?, ?)",
                    (source_db_id, target_db_id),
                )

    # Recompute citation_count for every imported paper
    for db_id in id_map.values():
        count = conn.execute(
            "SELECT COUNT(*) c FROM citations WHERE target_paper_id = ?", (db_id,)
        ).fetchone()["c"]
        conn.execute("UPDATE papers SET citation_count = ? WHERE id = ?", (count, db_id))

    conn.commit()
    conn.close()

    return {"imported_papers": len(rows), "message": "Dataset imported and citation graph updated"}


@router.delete("/import")
def delete_dataset():
    reset_db()
    return {"message": "Dataset cleared"}


@router.get("/import/stats")
def dataset_stats():
    conn = get_connection()
    stats = {
        "papers": conn.execute("SELECT COUNT(*) c FROM papers").fetchone()["c"],
        "authors": conn.execute("SELECT COUNT(*) c FROM authors").fetchone()["c"],
        "citations": conn.execute("SELECT COUNT(*) c FROM citations").fetchone()["c"],
    }
    conn.close()
    return stats
