"""Paper endpoints: list, search/filter, and detail with references/cited-by."""
from fastapi import APIRouter, HTTPException, Query
from typing import Optional
from database.db import get_connection

router = APIRouter(prefix="/api/papers", tags=["papers"])


def _paper_row_to_dict(conn, row):
    authors = conn.execute(
        """SELECT a.name FROM authors a
           JOIN paper_authors pa ON pa.author_id = a.id
           WHERE pa.paper_id = ?""",
        (row["id"],),
    ).fetchall()
    d = dict(row)
    d["authors"] = [a["name"] for a in authors]
    return d


@router.get("")
def list_papers(
    search: Optional[str] = None,
    author: Optional[str] = None,
    year: Optional[int] = None,
    min_citations: Optional[int] = None,
    sort_by: str = Query("citations", enum=["citations", "pagerank", "title", "year"]),
):
    conn = get_connection()
    query = "SELECT DISTINCT p.* FROM papers p"
    joins = []
    conditions = []
    params = []

    if author:
        joins.append("JOIN paper_authors pa ON pa.paper_id = p.id JOIN authors a ON a.id = pa.author_id")
        conditions.append("a.name LIKE ?")
        params.append(f"%{author}%")
    if search:
        conditions.append("(p.title LIKE ? OR p.abstract LIKE ?)")
        params.extend([f"%{search}%", f"%{search}%"])
    if year:
        conditions.append("p.year = ?")
        params.append(year)
    if min_citations is not None:
        conditions.append("p.citation_count >= ?")
        params.append(min_citations)

    if joins:
        query += " " + " ".join(joins)
    if conditions:
        query += " WHERE " + " AND ".join(conditions)

    sort_map = {
        "citations": "p.citation_count DESC",
        "pagerank": "p.pagerank_score DESC",
        "title": "p.title ASC",
        "year": "p.year DESC",
    }
    query += f" ORDER BY {sort_map[sort_by]}"

    rows = conn.execute(query, params).fetchall()
    result = [_paper_row_to_dict(conn, r) for r in rows]
    conn.close()
    return result


@router.get("/{paper_id}")
def get_paper(paper_id: int):
    conn = get_connection()
    row = conn.execute("SELECT * FROM papers WHERE id = ?", (paper_id,)).fetchone()
    if not row:
        conn.close()
        raise HTTPException(status_code=404, detail="Paper not found")

    paper = _paper_row_to_dict(conn, row)

    ref_rows = conn.execute(
        """SELECT p.* FROM papers p
           JOIN citations c ON c.target_paper_id = p.id
           WHERE c.source_paper_id = ?""",
        (paper_id,),
    ).fetchall()
    cited_rows = conn.execute(
        """SELECT p.* FROM papers p
           JOIN citations c ON c.source_paper_id = p.id
           WHERE c.target_paper_id = ?""",
        (paper_id,),
    ).fetchall()

    paper["references"] = [_paper_row_to_dict(conn, r) for r in ref_rows]
    paper["cited_by"] = [_paper_row_to_dict(conn, r) for r in cited_rows]

    conn.close()
    return paper
