"""Full network endpoints for graph visualization (citation graph + collaboration graph)."""
from fastapi import APIRouter
from database.db import get_connection

router = APIRouter(prefix="/api/network", tags=["network"])


@router.get("")
def get_citation_network():
    conn = get_connection()
    papers = conn.execute(
        "SELECT id, title, year, citation_count, pagerank_score, community_id FROM papers"
    ).fetchall()
    citations = conn.execute("SELECT source_paper_id, target_paper_id FROM citations").fetchall()

    author_map = {}
    rows = conn.execute(
        """SELECT pa.paper_id, a.name FROM paper_authors pa JOIN authors a ON a.id = pa.author_id"""
    ).fetchall()
    for r in rows:
        author_map.setdefault(r["paper_id"], []).append(r["name"])

    nodes = [
        {
            "id": p["id"],
            "label": p["title"],
            "year": p["year"],
            "citation_count": p["citation_count"],
            "pagerank": p["pagerank_score"],
            "community": p["community_id"],
            "authors": author_map.get(p["id"], []),
        }
        for p in papers
    ]
    edges = [{"source": c["source_paper_id"], "target": c["target_paper_id"]} for c in citations]

    conn.close()
    return {"nodes": nodes, "edges": edges}


@router.get("/collaborations")
def get_collaboration_network():
    conn = get_connection()
    authors = conn.execute("SELECT id, name FROM authors").fetchall()
    pub_counts = {
        r["author_id"]: r["c"]
        for r in conn.execute(
            "SELECT author_id, COUNT(*) as c FROM paper_authors GROUP BY author_id"
        ).fetchall()
    }

    paper_author_rows = conn.execute("SELECT paper_id, author_id FROM paper_authors").fetchall()
    by_paper = {}
    for row in paper_author_rows:
        by_paper.setdefault(row["paper_id"], []).append(row["author_id"])

    edge_weights = {}
    for author_ids in by_paper.values():
        for i in range(len(author_ids)):
            for j in range(i + 1, len(author_ids)):
                key = tuple(sorted((author_ids[i], author_ids[j])))
                edge_weights[key] = edge_weights.get(key, 0) + 1

    nodes = [
        {"id": a["id"], "label": a["name"], "publications": pub_counts.get(a["id"], 0)}
        for a in authors
    ]
    edges = [{"source": s, "target": t, "weight": w} for (s, t), w in edge_weights.items()]

    conn.close()
    return {"nodes": nodes, "edges": edges}
