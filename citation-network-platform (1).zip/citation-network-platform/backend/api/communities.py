"""Community-detection endpoints."""
from fastapi import APIRouter, HTTPException
from services.graph_service import build_citation_graph
from algorithms.community_detection import detect_communities
from database.db import get_connection

router = APIRouter(prefix="/api/communities", tags=["communities"])


@router.get("")
def get_communities():
    graph = build_citation_graph()
    result = detect_communities(graph)

    conn = get_connection()
    conn.execute("UPDATE papers SET community_id = NULL")
    for community_id, node_ids in [(c["community_id"], c["paper_ids"]) for c in result["communities"]]:
        for node_id in node_ids:
            conn.execute("UPDATE papers SET community_id = ? WHERE id = ?", (community_id, node_id))
    conn.commit()

    enriched = []
    for c in result["communities"]:
        ids = c["paper_ids"]
        if not ids:
            continue
        q_marks = ",".join("?" * len(ids))
        papers = conn.execute(
            f"SELECT id, title, citation_count, pagerank_score FROM papers WHERE id IN ({q_marks}) ORDER BY pagerank_score DESC",
            ids,
        ).fetchall()
        authors = conn.execute(
            f"""SELECT DISTINCT a.name FROM authors a
                JOIN paper_authors pa ON pa.author_id = a.id
                WHERE pa.paper_id IN ({q_marks})""",
            ids,
        ).fetchall()
        avg_citations = sum(p["citation_count"] for p in papers) / len(papers) if papers else 0
        enriched.append(
            {
                "community_id": c["community_id"],
                "size": c["size"],
                "papers": [dict(p) for p in papers],
                "top_paper": dict(papers[0]) if papers else None,
                "authors": [a["name"] for a in authors],
                "avg_citations": round(avg_citations, 2),
            }
        )
    conn.close()

    return {
        "algorithm": result["algorithm"],
        "modularity": result["modularity"],
        "num_communities": result["num_communities"],
        "execution_time_ms": result["execution_time_ms"],
        "communities": enriched,
    }


@router.get("/{community_id}")
def get_community(community_id: int):
    conn = get_connection()
    papers = conn.execute(
        "SELECT id, title, citation_count, pagerank_score FROM papers WHERE community_id = ? ORDER BY pagerank_score DESC",
        (community_id,),
    ).fetchall()
    conn.close()
    if not papers:
        raise HTTPException(status_code=404, detail="Community not found or empty")
    return {"community_id": community_id, "papers": [dict(p) for p in papers], "size": len(papers)}
