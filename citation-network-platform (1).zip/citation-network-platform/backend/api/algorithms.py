"""Endpoints that run the real graph algorithms against the live citation graph."""
from fastapi import APIRouter, HTTPException
from models.schemas import TraversalRequest, PathRequest
from services.graph_service import build_citation_graph
from algorithms.bfs import bfs, find_path_bfs
from algorithms.dfs import dfs, find_path_dfs
from algorithms.pagerank import calculate_pagerank
from database.db import get_connection

router = APIRouter(prefix="/api", tags=["algorithms"])


def _titles_for(ids):
    if not ids:
        return {}
    conn = get_connection()
    q_marks = ",".join("?" * len(ids))
    rows = conn.execute(f"SELECT id, title FROM papers WHERE id IN ({q_marks})", ids).fetchall()
    conn.close()
    return {r["id"]: r["title"] for r in rows}


@router.post("/bfs")
def run_bfs(req: TraversalRequest):
    graph = build_citation_graph()
    result = bfs(graph, req.start_paper_id)
    if "error" in result:
        raise HTTPException(status_code=404, detail=result["error"])
    result["titles"] = _titles_for(result["traversal_order"])
    return result


@router.post("/dfs")
def run_dfs(req: TraversalRequest):
    graph = build_citation_graph()
    result = dfs(graph, req.start_paper_id)
    if "error" in result:
        raise HTTPException(status_code=404, detail=result["error"])
    result["titles"] = _titles_for(result["traversal_order"])
    return result


@router.post("/citation-path")
def citation_path(req: PathRequest):
    graph = build_citation_graph()
    if req.algorithm.lower() == "dfs":
        result = find_path_dfs(graph, req.start_paper_id, req.target_paper_id)
    else:
        result = find_path_bfs(graph, req.start_paper_id, req.target_paper_id)
    if "error" in result:
        raise HTTPException(status_code=404, detail=result["error"])
    if result.get("path_found"):
        result["titles"] = _titles_for(result["path"])
    return result


@router.get("/pagerank")
def pagerank():
    graph = build_citation_graph()
    result = calculate_pagerank(graph)

    conn = get_connection()
    for node_id, score in result["scores"].items():
        conn.execute("UPDATE papers SET pagerank_score = ? WHERE id = ?", (score, node_id))
    conn.commit()

    rows = conn.execute(
        "SELECT id, title, citation_count, pagerank_score FROM papers ORDER BY pagerank_score DESC"
    ).fetchall()
    conn.close()

    result["ranked_papers"] = [dict(r) for r in rows]
    return result
