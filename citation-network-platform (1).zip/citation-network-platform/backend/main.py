"""FastAPI application entry point for the Citation-Network Analytics Platform."""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from database.db import init_db
from api import papers, authors, network, statistics, algorithms, communities, collaborations, data_management

app = FastAPI(
    title="Citation-Network Analytics Platform API",
    description="Backend for exploring research citation networks: BFS/DFS traversal, "
                "PageRank, community detection, and author collaboration analysis.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(papers.router)
app.include_router(authors.router)
app.include_router(network.router)
app.include_router(statistics.router)
app.include_router(algorithms.router)
app.include_router(communities.router)
app.include_router(collaborations.router)
app.include_router(data_management.router)


@app.on_event("startup")
def on_startup():
    init_db()


@app.get("/api/health")
def health_check():
    return {"status": "ok", "service": "citation-network-analytics-api"}
