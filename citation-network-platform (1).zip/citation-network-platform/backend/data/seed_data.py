"""
Generates a realistic-looking SAMPLE/DEMO dataset of research papers, authors,
and citations, and loads it directly into the SQLite database.

Run with:  python -m data.seed_data
(run from inside backend/, with the virtual environment active)

This is fictional demo data, clearly generated for coursework purposes -- it
exists so BFS, DFS, PageRank, and community detection all produce interesting,
non-trivial results out of the box.
"""
import random
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from database.db import get_connection, init_db, reset_db  # noqa: E402

random.seed(42)

CLUSTERS = {
    "Graph Neural Networks": {
        "authors": ["A. Kapoor", "M. Chen", "R. Fontaine", "S. Iyer"],
        "titles": [
            "Message Passing Foundations for Graph Neural Networks",
            "Scalable Graph Convolutional Networks on Large Citation Graphs",
            "Attention Mechanisms for Heterogeneous Graph Learning",
            "Inductive Representation Learning on Dynamic Graphs",
            "Graph Sampling Strategies for Billion-Edge Networks",
            "Spectral Methods Revisited for Graph Neural Networks",
            "Self-Supervised Pretraining for Graph Representation Learning",
            "Benchmarking Graph Neural Networks on Citation Prediction",
        ],
    },
    "Distributed Systems": {
        "authors": ["P. Novak", "L. Andersson", "K. Osei", "T. Bram"],
        "titles": [
            "Consensus Protocols for Geo-Distributed Databases",
            "Fault-Tolerant Replication in Large-Scale Storage Systems",
            "Low-Latency Coordination for Microservice Architectures",
            "Byzantine Fault Tolerance Under Network Partitions",
            "Elastic Resource Scheduling for Distributed Workloads",
            "Causal Consistency Models for Edge Computing",
            "Sharding Strategies for High-Throughput Transaction Systems",
            "Vector Clocks and Their Modern Applications",
        ],
    },
    "NLP Transformers": {
        "authors": ["Y. Tanaka", "D. Okafor", "E. Moreau", "H. Lindqvist"],
        "titles": [
            "Attention Is a Strong Baseline for Sequence Modeling",
            "Efficient Transformers for Long-Document Understanding",
            "Instruction Tuning for Low-Resource Languages",
            "Retrieval-Augmented Generation for Open-Domain QA",
            "Scaling Laws for Transformer Language Models",
            "Cross-Lingual Transfer in Multilingual Transformers",
            "Sparse Attention Patterns for Efficient Inference",
            "Evaluating Factuality in Large Language Model Outputs",
        ],
    },
    "Computer Vision": {
        "authors": ["J. Kowalski", "N. Alvarado", "F. Zimmer", "C. Reyes"],
        "titles": [
            "Convolutional Backbones for Real-Time Object Detection",
            "Vision Transformers for Dense Prediction Tasks",
            "Self-Supervised Contrastive Learning for Image Representations",
            "Multi-Scale Feature Fusion for Semantic Segmentation",
            "Generative Adversarial Networks for Data Augmentation",
            "3D Scene Reconstruction from Sparse Views",
            "Efficient Neural Architectures for Edge Vision",
            "Video Understanding with Spatiotemporal Transformers",
        ],
    },
    "Cybersecurity ML": {
        "authors": ["G. Petrov", "B. Nakamura", "W. Adeyemi", "V. Rossi"],
        "titles": [
            "Machine Learning for Network Intrusion Detection",
            "Adversarial Robustness in Malware Classification",
            "Anomaly Detection for Zero-Day Exploit Discovery",
            "Federated Learning for Privacy-Preserving Threat Detection",
            "Graph-Based Detection of Lateral Movement in Networks",
            "Explainable AI for Security Operations Centers",
            "Behavioral Analysis of Botnet Command-and-Control Traffic",
            "Deep Learning for Phishing URL Detection",
        ],
    },
}

ABSTRACT_TEMPLATE = (
    "This paper studies {topic} and proposes a method that improves performance "
    "over prior baselines on standard benchmarks. We present an analysis of the "
    "approach, report empirical results, and discuss implications for future work "
    "in this area. (Sample/demo abstract generated for coursework.)"
)


def generate_dataset():
    """Returns (papers, authors_by_cluster) where papers include id, title, year,
    abstract, authors (list), cluster, and citations (list of paper ids it cites)."""
    papers = []
    paper_id_by_cluster = {c: [] for c in CLUSTERS}
    next_id = 1

    for cluster, info in CLUSTERS.items():
        for i, title in enumerate(info["titles"]):
            year = 2018 + (i % 8)
            n_authors = random.randint(2, 3)
            authors = random.sample(info["authors"], n_authors)
            papers.append(
                {
                    "id": next_id,
                    "title": title,
                    "year": year,
                    "abstract": ABSTRACT_TEMPLATE.format(topic=title.lower()),
                    "authors": authors,
                    "cluster": cluster,
                }
            )
            paper_id_by_cluster[cluster].append(next_id)
            next_id += 1

    # Build citations: mostly within-cluster (later papers cite earlier ones),
    # plus a handful of cross-cluster citations for realism.
    for cluster, ids in paper_id_by_cluster.items():
        for idx, pid in enumerate(ids):
            possible_targets = ids[:idx]  # only cite earlier papers in same cluster
            if possible_targets:
                n_cites = min(len(possible_targets), random.randint(2, 5))
                targets = random.sample(possible_targets, n_cites)
                papers[pid - 1]["cites"] = targets
            else:
                papers[pid - 1]["cites"] = []

    # Cross-cluster citations (~15) to link communities together, still preserving structure
    all_ids = [p["id"] for p in papers]
    cross_links = 0
    while cross_links < 25:
        source = random.choice(papers)
        target_id = random.choice(all_ids)
        target = papers[target_id - 1]
        if target["cluster"] != source["cluster"] and target["id"] not in source["cites"] and target["id"] != source["id"]:
            source["cites"].append(target["id"])
            cross_links += 1

    return papers


def load_into_db(papers):
    conn = get_connection()

    author_name_to_id = {}
    paper_id_to_db_id = {}

    for p in papers:
        cur = conn.execute(
            "INSERT INTO papers (title, abstract, year, doi, citation_count, pagerank_score) VALUES (?, ?, ?, ?, 0, 0)",
            (p["title"], p["abstract"], p["year"], f"10.9999/demo.{p['id']}"),
        )
        db_id = cur.lastrowid
        paper_id_to_db_id[p["id"]] = db_id

        for name in p["authors"]:
            if name not in author_name_to_id:
                author_id = conn.execute("INSERT INTO authors (name) VALUES (?)", (name,)).lastrowid
                author_name_to_id[name] = author_id
            conn.execute(
                "INSERT OR IGNORE INTO paper_authors (paper_id, author_id) VALUES (?, ?)",
                (db_id, author_name_to_id[name]),
            )

    for p in papers:
        source_db_id = paper_id_to_db_id[p["id"]]
        for target_paper_id in p.get("cites", []):
            target_db_id = paper_id_to_db_id[target_paper_id]
            conn.execute(
                "INSERT OR IGNORE INTO citations (source_paper_id, target_paper_id) VALUES (?, ?)",
                (source_db_id, target_db_id),
            )

    for db_id in paper_id_to_db_id.values():
        count = conn.execute(
            "SELECT COUNT(*) c FROM citations WHERE target_paper_id = ?", (db_id,)
        ).fetchone()["c"]
        conn.execute("UPDATE papers SET citation_count = ? WHERE id = ?", (count, db_id))

    conn.commit()
    conn.close()


def write_csv_exports(papers):
    """Also writes sample_data/papers.csv and authors.csv for reference / re-import demos."""
    import csv

    sample_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "sample_data"))
    os.makedirs(sample_dir, exist_ok=True)

    with open(os.path.join(sample_dir, "papers.csv"), "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["paper_id", "title", "authors", "year", "abstract", "references"])
        for p in papers:
            writer.writerow(
                [
                    p["id"],
                    p["title"],
                    ";".join(p["authors"]),
                    p["year"],
                    p["abstract"],
                    ";".join(str(c) for c in p.get("cites", [])),
                ]
            )

    all_authors = sorted({a for p in papers for a in p["authors"]})
    with open(os.path.join(sample_dir, "authors.csv"), "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["name"])
        for name in all_authors:
            writer.writerow([name])


def main():
    print("Resetting database...")
    reset_db()
    print("Generating sample dataset (5 research clusters, 40 papers)...")
    papers = generate_dataset()
    print(f"  {len(papers)} papers, {sum(len(p.get('cites', [])) for p in papers)} citations")
    print("Loading into SQLite...")
    load_into_db(papers)
    print("Writing CSV exports to sample_data/...")
    write_csv_exports(papers)
    print("Done. Sample/demo data loaded successfully.")


if __name__ == "__main__":
    main()
