"""
Research community detection.

Uses NetworkX's greedy modularity maximization (Clauset-Newman-Moore) on the
undirected version of the citation graph: it repeatedly merges the pair of
communities that most increases modularity, a measure of how much more
densely connected papers are within a group than would be expected by chance.

Time complexity: roughly O(E * V) worst case for greedy modularity on sparse graphs
Space complexity: O(V + E)
"""
import time
import networkx as nx
from networkx.algorithms.community import greedy_modularity_communities, modularity


def detect_communities(graph):
    if graph.number_of_nodes() == 0:
        return {"communities": [], "modularity": 0, "execution_time_ms": 0}

    undirected = graph.to_undirected()

    t0 = time.perf_counter()
    communities = list(greedy_modularity_communities(undirected))
    elapsed = (time.perf_counter() - t0) * 1000

    try:
        mod_score = modularity(undirected, communities)
    except Exception:
        mod_score = None

    node_to_community = {}
    community_list = []
    for idx, community_nodes in enumerate(communities):
        node_ids = list(community_nodes)
        for n in node_ids:
            node_to_community[n] = idx
        community_list.append({"community_id": idx, "paper_ids": node_ids, "size": len(node_ids)})

    return {
        "algorithm": "Greedy Modularity Community Detection",
        "communities": community_list,
        "node_to_community": node_to_community,
        "modularity": round(mod_score, 4) if mod_score is not None else None,
        "execution_time_ms": round(elapsed, 4),
        "num_communities": len(community_list),
    }
