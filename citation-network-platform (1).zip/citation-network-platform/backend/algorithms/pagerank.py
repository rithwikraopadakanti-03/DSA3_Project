"""
PageRank over the citation graph, computed with NetworkX's power-iteration
implementation (the classic random-surfer model applied to citations instead
of web pages: a paper is "important" if it is cited by other important papers).

Time complexity: O(k * (V + E)) for k iterations until convergence
Space complexity: O(V)
"""
import time
import networkx as nx


def calculate_pagerank(graph, alpha=0.85, max_iter=100):
    if graph.number_of_nodes() == 0:
        return {"scores": {}, "execution_time_ms": 0}

    t0 = time.perf_counter()
    scores = nx.pagerank(graph, alpha=alpha, max_iter=max_iter)
    elapsed = (time.perf_counter() - t0) * 1000

    ranked = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)

    return {
        "algorithm": "PageRank",
        "damping_factor": alpha,
        "scores": scores,
        "ranked_ids": [node_id for node_id, _ in ranked],
        "execution_time_ms": round(elapsed, 4),
        "iterations_cap": max_iter,
    }
