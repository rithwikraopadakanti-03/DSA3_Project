"""
Breadth-First Search over the citation graph.

Data structure: queue (collections.deque)
Traversal: level-by-level, following outgoing citation edges (source -> target)
Time complexity: O(V + E)
Space complexity: O(V)
"""
import time
from collections import deque


def bfs(graph, start_node):
    """Full BFS traversal from start_node. Returns order, levels, and stats."""
    if start_node not in graph:
        return {"error": f"Paper {start_node} not found in graph"}

    t0 = time.perf_counter()
    visited = {start_node}
    queue = deque([(start_node, 0)])
    order = []
    levels = {}
    edges_explored = 0

    while queue:
        node, depth = queue.popleft()
        order.append(node)
        levels.setdefault(depth, []).append(node)
        for neighbor in graph.successors(node):
            edges_explored += 1
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append((neighbor, depth + 1))

    elapsed = (time.perf_counter() - t0) * 1000  # ms

    return {
        "algorithm": "BFS",
        "start_node": start_node,
        "traversal_order": order,
        "levels": levels,
        "nodes_visited": len(order),
        "edges_explored": edges_explored,
        "max_depth": max(levels.keys()) if levels else 0,
        "execution_time_ms": round(elapsed, 4),
        "data_structure": "Queue (FIFO)",
    }


def find_path_bfs(graph, start_node, target_node):
    """Shortest citation path (fewest hops) between two papers using BFS."""
    if start_node not in graph or target_node not in graph:
        return {"error": "Start or target paper not found in graph", "path_found": False}

    t0 = time.perf_counter()
    visited = {start_node}
    queue = deque([start_node])
    parent = {start_node: None}
    nodes_visited = 0

    found = False
    while queue:
        node = queue.popleft()
        nodes_visited += 1
        if node == target_node:
            found = True
            break
        for neighbor in graph.successors(node):
            if neighbor not in visited:
                visited.add(neighbor)
                parent[neighbor] = node
                queue.append(neighbor)

    elapsed = (time.perf_counter() - t0) * 1000

    if not found:
        return {
            "algorithm": "BFS",
            "path_found": False,
            "nodes_visited": nodes_visited,
            "execution_time_ms": round(elapsed, 4),
        }

    path = []
    node = target_node
    while node is not None:
        path.append(node)
        node = parent[node]
    path.reverse()

    return {
        "algorithm": "BFS",
        "path_found": True,
        "path": path,
        "path_length": len(path) - 1,
        "nodes_visited": nodes_visited,
        "execution_time_ms": round(elapsed, 4),
    }
