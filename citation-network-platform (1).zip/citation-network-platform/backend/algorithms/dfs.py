"""
Depth-First Search over the citation graph.

Data structure: explicit stack
Traversal: depth-first, following outgoing citation edges (source -> target)
Time complexity: O(V + E)
Space complexity: O(V)
"""
import time


def dfs(graph, start_node):
    """Full DFS traversal from start_node using an explicit stack. Returns order and stats."""
    if start_node not in graph:
        return {"error": f"Paper {start_node} not found in graph"}

    t0 = time.perf_counter()
    visited = set()
    stack = [(start_node, 0)]
    order = []
    depth_at = {}
    edges_explored = 0
    max_depth = 0

    while stack:
        node, depth = stack.pop()
        if node in visited:
            continue
        visited.add(node)
        order.append(node)
        depth_at[node] = depth
        max_depth = max(max_depth, depth)

        # push neighbors in reverse so traversal visits them in natural order
        neighbors = list(graph.successors(node))
        for neighbor in reversed(neighbors):
            edges_explored += 1
            if neighbor not in visited:
                stack.append((neighbor, depth + 1))

    elapsed = (time.perf_counter() - t0) * 1000

    return {
        "algorithm": "DFS",
        "start_node": start_node,
        "traversal_order": order,
        "depth_at": depth_at,
        "nodes_visited": len(order),
        "edges_explored": edges_explored,
        "max_depth": max_depth,
        "execution_time_ms": round(elapsed, 4),
        "data_structure": "Stack (LIFO, explicit)",
    }


def find_path_dfs(graph, start_node, target_node):
    """A citation path (not necessarily shortest) between two papers using DFS."""
    if start_node not in graph or target_node not in graph:
        return {"error": "Start or target paper not found in graph", "path_found": False}

    t0 = time.perf_counter()
    visited = set()
    stack = [(start_node, [start_node])]
    nodes_visited = 0
    found_path = None

    while stack:
        node, path = stack.pop()
        if node in visited:
            continue
        visited.add(node)
        nodes_visited += 1

        if node == target_node:
            found_path = path
            break

        for neighbor in graph.successors(node):
            if neighbor not in visited:
                stack.append((neighbor, path + [neighbor]))

    elapsed = (time.perf_counter() - t0) * 1000

    if found_path is None:
        return {
            "algorithm": "DFS",
            "path_found": False,
            "nodes_visited": nodes_visited,
            "execution_time_ms": round(elapsed, 4),
        }

    return {
        "algorithm": "DFS",
        "path_found": True,
        "path": found_path,
        "path_length": len(found_path) - 1,
        "nodes_visited": nodes_visited,
        "execution_time_ms": round(elapsed, 4),
    }
